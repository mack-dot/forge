"""Exercise held-anchor integrity guards with actual compiled proof objects.

This is local test orchestration. It dispatches existing Rocq and the existing
audit driver. It neither checks proofs itself nor authenticates an expected
digest supplied together with an untrusted candidate.
"""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import time

ROOT = Path('/Users/mackianni/forge')
HERE = Path(__file__).resolve().parent
GOOD = ROOT / 'results/campaign-observation-kernel-2026-11-02/attempt-0001'
SOURCE = ROOT / 'results/campaign-runtime-projection-2026-11-02/transition-hidden-fields'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

def command(argv, log):
    start = time.monotonic()
    with log.open('wb') as stream:
        run = subprocess.run(argv, stdout=stream, stderr=subprocess.STDOUT)
    result = {'argv': argv, 'actual_exit': run.returncode,
              'wall_seconds': time.monotonic() - start}
    write(log.with_suffix('.command.json'), result)
    return result

anchor = GOOD / 'expected-inputs.json'
driver = GOOD / 'recheck_inside.py'
original_files = [anchor, driver, SOURCE / 'ObservedTransitions.v', SOURCE / 'ObservedTransitions.vo']
before = {str(path): sha(path) for path in original_files}
write(HERE / 'identities-before.json', before)
expected = json.loads(anchor.read_text())
assert before[str(SOURCE / 'ObservedTransitions.vo')] == expected['candidate_object_sha256']
assert before[str(SOURCE / 'ObservedTransitions.v')] == expected['candidate_source_sha256']
assert json.loads((GOOD / 'postflight.json').read_text())['actual_kernel_exit'] == 0

byte_case = HERE / 'corrupt-object'
weak_case = HERE / 'weakened-statement'
for case in (byte_case, weak_case):
    (case / 'fixture').mkdir(parents=True, exist_ok=False)
    (case / 'kernel-output').mkdir()

data = bytearray((SOURCE / 'ObservedTransitions.vo').read_bytes())
offset = len(data) // 2
data[offset] ^= 1
(byte_case / 'fixture/ObservedTransitions.vo').write_bytes(data)
write(byte_case / 'mutation.json', {'offset': offset, 'xor': 1,
    'original_sha256': expected['candidate_object_sha256'],
    'mutated_sha256': sha(byte_case / 'fixture/ObservedTransitions.vo')})

text = (SOURCE / 'ObservedTransitions.v').read_text()
assert text.count('(seq 0 21)') == 1 and text.count('= map Some observed_states.') == 1
weakened = text.replace('(seq 0 21)', '(seq 0 20)').replace(
    '= map Some observed_states.', '= map Some (firstn 20 observed_states).')
(weak_case / 'fixture/ObservedTransitions.v').write_text(weakened)
compile_argv = json.loads((ROOT / 'results/campaign-runtime-projection-2026-11-02/hidden-fields-commands.json').read_text())[0]['argv']
compile_argv[compile_argv.index('--name') + 1] = 'forge-observation-weakened-compile-20261102-0001'
compile_argv = [part.replace(str(SOURCE), str(weak_case / 'fixture')) for part in compile_argv]
compiled = command(compile_argv, weak_case / 'compile.log')
assert compiled['actual_exit'] == 0, 'WEAK_FIXTURE_MUST_BE_A_REAL_COMPILED_PROOF'
assert sha(weak_case / 'fixture/ObservedTransitions.vo') != expected['candidate_object_sha256']
write(weak_case / 'mutation.json', {'kind': 'Twenty projected frames instead of required twenty-one',
    'same_module_and_lemma_names': True, 'real_rocq_compile_exit': 0,
    'source_sha256': sha(weak_case / 'fixture/ObservedTransitions.v'),
    'object_sha256': sha(weak_case / 'fixture/ObservedTransitions.vo'),
    'expected_object_sha256': expected['candidate_object_sha256'],
    'accepted_specification_changed': False})

rows = []
for label, case in [('corrupt-object', byte_case), ('weakened-statement', weak_case)]:
    argv = json.loads((GOOD / 'kernel-invocation.json').read_text())['argv']
    argv[argv.index('--name') + 1] = 'forge-observation-negative-' + label + '-20261102-0001'
    for index, part in enumerate(argv):
        if part.endswith('target=/observed,readonly'):
            argv[index] = 'type=bind,source=' + str(case / 'fixture') + ',target=/observed,readonly'
        elif part.endswith('target=/records'):
            argv[index] = 'type=bind,source=' + str(case / 'kernel-output') + ',target=/records'
    run = command(argv, case / 'container.log')
    result = json.loads((case / 'kernel-output/result.json').read_text())
    intended = 'AssertionError: DEPENDENCY_BYTES:/observed/ObservedTransitions.vo'
    assert run['actual_exit'] == 1 and result.get('failure') == intended, 'INTENDED_IDENTITY_REFUSAL'
    assert result['result'] == 'NOT_ESTABLISHED' and result.get('actual_kernel_exit') is None
    assert not (case / 'kernel-output/kernel-start.json').exists()
    assert not (case / 'kernel-output/independent-kernel.log').exists()
    assert 'STARTING_REAL_INDEPENDENT_KERNEL_RECHECK' not in (case / 'container.log').read_text()
    state = subprocess.run(['docker', 'inspect', '--format', '{{json .State}}', argv[argv.index('--name') + 1]],
                           capture_output=True, text=True)
    assert state.returncode == 0
    actual_state = json.loads(state.stdout)
    write(case / 'container-state.json', actual_state)
    assert actual_state['ExitCode'] == 1 and actual_state['OOMKilled'] is False
    rows.append({'case': label, 'expected_exit': 1, 'actual_exit': run['actual_exit'],
        'expected_reason': intended, 'actual_reason': result['failure'],
        'kernel_launched': False, 'accepted': False, 'acceptance_passed': True,
        'wall_seconds': run['wall_seconds'],
        'same_held_expected_anchor_sha256': sha(anchor), 'same_driver_sha256': sha(driver)})
    write(HERE / 'results.json', rows)
    print(json.dumps(rows[-1], sort_keys=True), flush=True)

after = {str(path): sha(path) for path in original_files}
assert before == after
write(HERE / 'identities-after.json', after)
write(HERE / 'summary.json', {'actual_control_matrix_exit': 0, 'cases': len(rows),
    'original_inputs_unchanged': True, 'weaker_fixture_real_compile_exit': compiled['actual_exit'],
    'previous_positive_kernel_exit': 0, 'positive_kernel_rerun': False,
    'held_anchor_scope': 'Local trusted operator retains original expectation; not durable provenance',
    'both_candidate_and_expected_anchor_tampering_supported': False,
    'cross_run_receipt_reuse_enabled': False, 'accepted_claim': False,
    'end_to_end': False})
