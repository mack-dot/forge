"""Dispatch the unchanged published audit over exact historical .vo inputs."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

OUT = Path('/records')
EXPECTED = json.loads(Path('/expected.json').read_text())

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

def identity():
    observed = {}
    for name, expected in EXPECTED['closure_sha256'].items():
        actual = sha(Path(name))
        assert actual == expected, 'DEPENDENCY_BYTES:' + name
        observed[name] = actual
    for name, expected in EXPECTED['tools'].items():
        path = Path('/audit-tools') / name.removeprefix('tools/') if name.startswith('tools/') else Path('/allowed-axioms.txt')
        assert sha(path) == expected, 'AUDIT_CODE_BYTES:' + name
    tool_files={str(p.relative_to('/audit-tools')):sha(p) for p in Path('/audit-tools').rglob('*') if p.is_file()}
    assert tool_files=={n.removeprefix('tools/'):h for n,h in EXPECTED['tools'].items() if n.startswith('tools/')}, 'EXACT_AUDIT_TOOL_MEMBERSHIP'
    pyfiles = {str(p.relative_to('/pydeps')): sha(p) for p in Path('/pydeps').rglob('*') if p.is_file()}
    assert pyfiles == EXPECTED['python_dependencies'], 'PYTHON_DEPENDENCIES'
    return observed

start = time.monotonic()
result = {'result': 'NOT_ESTABLISHED', 'end_to_end': False,
          'scope': EXPECTED['scope'], 'source_compilation': False,
          'accepted_claim': False, 'candidate_compiled_before_this_run': True, 'new_process': True, 'independent_physical_machine': False}
processes = []
try:
    assert (os.getuid(), os.getgid()) == (1000, 1000)
    assert sys.version_info[:3] == (3, 12, 3)
    save('input-identities-before.json', identity())
    version = subprocess.run(['rocqchk', '--version'], capture_output=True, text=True)
    save('rocqchk-version.json', {'exit_code': version.returncode, 'stdout': version.stdout, 'stderr': version.stderr})
    assert version.returncode == 0 and '9.2' in version.stdout + version.stderr
    sys.path[:0] = ['/audit-tools', '/pydeps']
    from oft.check import _rocqchk, allowed_axioms, rocqchk_axioms
    allowed = allowed_axioms('/', 'allowed-axioms.txt')
    command = EXPECTED['kernel_command']
    assert command[:4] == ['rocqchk', '-o', '-bytecode-compiler', 'no']
    roots=EXPECTED['root_modules']
    assert command[-len(roots):]==roots
    save('kernel-start.json', {'command': command, 'input_files': len(EXPECTED['closure_sha256']), 'expected_source': 'historical anchored pool plus exact local candidate objects; no claim adoption'})
    print('STARTING_REAL_INDEPENDENT_KERNEL_RECHECK', flush=True)
    run_code = subprocess.run.__code__
    def trace(frame, event, arg):
        if frame.f_code is run_code and event == 'return' and isinstance(arg, subprocess.CompletedProcess):
            processes.append({'command': arg.args, 'exit_code': arg.returncode})
            save('independent-processes.json', processes)
        return trace
    sys.settrace(trace)
    try:
        count = _rocqchk('/work', command[4:-len(roots)], roots, allowed, str(OUT / 'independent-kernel.log'))
    finally:
        sys.settrace(None)
    assert processes == [{'command': command, 'exit_code': 0}], 'ACTUAL_KERNEL_PROCESS'
    raw = (OUT / 'independent-kernel.log').read_text()
    finished, axioms = rocqchk_axioms(raw)
    assert finished and count==len(axioms) and count>0 and not (axioms-allowed)
    modules = re.findall(r'^Checking library: (.+)$', raw, re.M)
    assert len(modules)==len(set(modules)) and set(EXPECTED['required_modules'])<=set(modules), 'ROOT_MODULES'
    loaded = re.findall(r'^\[intern (.+\.vo) \.\.\.$', raw, re.M)
    assert len(loaded)==len(set(loaded)) and set(EXPECTED['required_files'])<=set(loaded)<=set(EXPECTED['closure_sha256']), 'ANCHORED_INPUT_CLOSURE'
    save('actual-closure-identities.json',{name:EXPECTED['closure_sha256'][name] for name in loaded})
    save('actual-assumptions.json',sorted(axioms))
    save('input-identities-after.json', identity())
    result.update(result='PASSED', actual_kernel_exit=0, modules=len(modules),
                  closure_assumptions=count, kernel_log_sha256=sha(OUT / 'independent-kernel.log'))
except BaseException as error:
    result['failure'] = type(error).__name__ + ': ' + str(error)
    raise
finally:
    result['wall_seconds'] = time.monotonic() - start
    save('result.json', result)
    print(json.dumps(result, sort_keys=True), flush=True)
