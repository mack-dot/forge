"""Actual pre-execution identity refusals with held expectations unchanged."""
import json,shutil,subprocess
from pathlib import Path
ROOT=Path('/Users/mackianni/forge');OUT=Path(__file__).resolve().parent
rows=[]
def run(case,cmd):
 with (OUT/(case+'.log')).open('xb') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 rows.append({'case':case,'argv':cmd,'actual_exit':p.returncode,'expected_exit':1})
 (OUT/'identity-control-commands.json').write_text(json.dumps(rows,indent=2)+'\n')
 assert p.returncode==1,case
 print(case+': '+str(p.returncode),flush=True)
bad=OUT/'corrupt-proof';bad.mkdir(exist_ok=False)
shutil.copyfile(OUT/'rebuild/Behavior.v',bad/'Behavior.v')
data=bytearray((OUT/'rebuild/Behavior.vo').read_bytes());data[0]^=1;(bad/'Behavior.vo').write_bytes(data)
logs=OUT/'corrupt-proof-kernel-output';logs.mkdir()
cmd=json.loads((OUT/'kernel-invocation.json').read_text())['argv']
cmd=[x.replace(str(OUT/'rebuild'),str(bad)).replace(str(OUT/'kernel-output'),str(logs)) for x in cmd]
cmd[cmd.index('--name')+1]='forge-correspondence-corrupt-proof-20261103-0001'
run('corrupt-proof',cmd)
result=json.loads((logs/'result.json').read_text())
assert 'DEPENDENCY_BYTES:/behavior/Behavior.vo' in result['failure']
assert not (logs/'kernel-start.json').exists()

badelf=OUT/'substituted.elf';original=Path('/Users/mackianni/forge-stage9-signing-0003/artifacts/r1-signed/x/packaged.elf')
data=bytearray(original.read_bytes());data[-1]^=1;badelf.write_bytes(data)
logs=OUT/'substituted-elf-capture';logs.mkdir()
cmd=next(r['argv'] for r in json.loads((OUT/'observation-commands.json').read_text()) if r['label']=='baseline')
cmd=[x.replace(str(original),str(badelf)).replace(str(OUT/'baseline/capture'),str(logs)) for x in cmd]
cmd[cmd.index('--name')+1]='forge-correspondence-substituted-elf-20261103-0001'
run('substituted-elf',cmd)
assert 'assert sha(ELF)' in (OUT/'substituted-elf.log').read_text()
assert not (logs/'execution-before.json').exists()
(OUT/'identity-controls.json').write_text(json.dumps({'actual_exit':0,'corrupt_proof_exit':1,'wrong_elf_exit':1,'kernel_started_for_corrupt_proof':False,'guest_started_for_wrong_elf':False,'expected_identities_changed':False,'end_to_end':False},indent=2)+'\n')
