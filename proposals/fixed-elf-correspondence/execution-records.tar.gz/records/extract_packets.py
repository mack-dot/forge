import hashlib,json,tarfile
from pathlib import Path
for item in json.loads(Path('/inputs/portable-archives.json').read_text()):
 source=Path('/inputs')/item['name']
 assert hashlib.sha256(source.read_bytes()).hexdigest()==item['sha256']
 with tarfile.open(source,'r:gz') as archive:archive.extractall('/output',filter='data')
print('EXTRACTED_WITH_STANDARD_DATA_FILTER')
