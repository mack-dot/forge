"""Fresh rebuild plus full existing recursive kernel dispatch. No admission."""
import hashlib,json,shutil,subprocess,time
from pathlib import Path
ROOT=Path('/Users/mackianni/forge')
OUT=Path(__file__).resolve().parent
PREV=ROOT/'results/vertical-slice-audit-2026-11-03/attempt-0001'
KERNEL=ROOT/'results/runtime-process-prefix-kernel-2026-11-03/attempt-0001'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(n,x):(OUT/n).write_text(json.dumps(x,indent=2,sort_keys=True)+'\n')
def run(n,cmd):
 start=time.monotonic()
 with (OUT/(n+'.log')).open('xb') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 save(n+'-command.json',{'argv':cmd,'actual_exit':p.returncode,'wall_seconds':time.monotonic()-start,'end_to_end':False})
 print(n+': '+str(p.returncode),flush=True)
 assert p.returncode==0,n

rebuild=OUT/'rebuild';rebuild.mkdir(exist_ok=False)
shutil.copyfile(PREV/'positive/Behavior.v',rebuild/'Behavior.v')
assert sha(rebuild/'Behavior.v')=='5a230c7e1b99652e720fbe134c383a66247a0f08f460ea98546f136831a731aa'
cmd=json.loads((PREV/'positive-command.json').read_text())['argv']
cmd[cmd.index('--name')+1]='forge-correspondence-behavior-rebuild-20261103-0001'
cmd=[x.replace(str(PREV/'positive'),str(rebuild)) for x in cmd]
run('behavior-rebuild',cmd)
assert sha(rebuild/'Behavior.vo')==sha(PREV/'positive/Behavior.vo')=='f1d3b7e22f0ba9f40607f555c7fc15b85fdf84598bc1a5b6d47d7f1a33af8cca'
save('reproduction.json',{'actual_exit':0,'source_sha256':sha(rebuild/'Behavior.v'),'object_sha256':sha(rebuild/'Behavior.vo'),'byte_identical':True})
cmd2=json.loads((PREV/'audit-command.json').read_text())['argv']
cmd2[cmd2.index('--name')+1]='forge-correspondence-exit-bridge-20261103-0001'
cmd2=[x.replace(str(PREV/'positive'),str(rebuild)).replace(str(PREV/'audit'),str(OUT/'bridge')).replace('ForgeSliceAudit','ForgeExitBridge').replace('/trial/Audit.v','/trial/ExitBridge.v') for x in cmd2]
run('exit-bridge',cmd2)

expected=json.loads((KERNEL/'expected-inputs.json').read_text())
cmd=json.loads((KERNEL/'kernel-invocation.json').read_text())['argv']
cmd[cmd.index('--name')+1]='forge-correspondence-full-kernel-20261103-0001'
for i,x in enumerate(cmd):
 if 'source='+str(KERNEL/'expected-inputs.json') in x:cmd[i]=x.replace(str(KERNEL/'expected-inputs.json'),str(OUT/'expected-inputs.json'))
 if 'source='+str(KERNEL/'recheck_inside.py') in x:cmd[i]=x.replace(str(KERNEL/'recheck_inside.py'),str(OUT/'recheck_inside.py'))
 if 'source='+str(KERNEL/'kernel-output') in x:cmd[i]=x.replace(str(KERNEL/'kernel-output'),str(OUT/'kernel-output'))
image=cmd.index('python3')-1
cmd[image:image]=['--mount','type=bind,source='+str(rebuild)+',target=/behavior,readonly','--mount','type=bind,source='+str(OUT/'bridge')+',target=/bridge,readonly']
roots=expected['root_modules']+['ForgeSlice.Behavior','ForgeExitBridge.ExitBridge']
expected['kernel_command']=expected['kernel_command'][:-len(expected['root_modules'])]+['-Q','/behavior','ForgeSlice','-Q','/bridge','ForgeExitBridge']+roots
expected['root_modules']=roots;expected['required_modules']=roots
for folder,name,inside in [(rebuild,'Behavior','/behavior'),(OUT/'bridge','ExitBridge','/bridge')]:
 expected['closure_sha256'][inside+'/'+name+'.vo']=sha(folder/(name+'.vo'))
 expected['source_sha256'][str(folder/(name+'.v'))]=sha(folder/(name+'.v'))
 expected['required_files'].append(inside+'/'+name+'.vo')
expected['scope']='Full recursive independent replay of fixed GCD behavior, explicit modeled ExitEv0, and prior process-prefix roots. No physical refinement or claim adoption.'
save('expected-inputs.json',expected)
shutil.copyfile(KERNEL/'recheck_inside.py',OUT/'recheck_inside.py')
assert sha(KERNEL/'recheck_inside.py')==sha(OUT/'recheck_inside.py')
(OUT/'kernel-output').mkdir(exist_ok=False)
save('kernel-invocation.json',{'argv':cmd,'expected_inputs_sha256':sha(OUT/'expected-inputs.json'),'unchanged_runner_sha256':sha(OUT/'recheck_inside.py'),'end_to_end':False})
run('full-kernel',cmd)
for name,digest in expected['source_sha256'].items():assert sha(Path(name))==digest,name
save('source-postflight.json',{'actual_exit':0,'sources_checked':len(expected['source_sha256']),'source_identity_unchanged':True,'end_to_end':False})
