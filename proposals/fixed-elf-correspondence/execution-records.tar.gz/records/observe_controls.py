"""Existing finite observer plus a deliberate runtime-interference control."""
import hashlib,json,shutil,subprocess,time
from pathlib import Path
ROOT=Path('/Users/mackianni/forge')
OUT=Path(__file__).resolve().parent
OLD=ROOT/'results/fixed-elf-observer-2026-11-03/attempt-0003'
rows=[]
def run(label,cmd,expected):
 start=time.monotonic()
 with (OUT/(label+'.log')).open('xb') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 row={'label':label,'argv':cmd,'actual_exit':p.returncode,'expected_exit':expected,'wall_seconds':time.monotonic()-start}
 rows.append(row);(OUT/'observation-commands.json').write_text(json.dumps(rows,indent=2)+'\n')
 print(label+': '+str(p.returncode),flush=True)
 assert p.returncode==expected,label

# Authenticate the complete existing observer producer before fresh use.
chain=ROOT/'results/fixed-elf-observer-2026-11-03/attempt-0002'
cmd=json.loads((chain/'producer-chain-readonly-command.json').read_text())['argv']
new=OUT/'producer-chain';new.mkdir(exist_ok=False)
cmd=[x.replace(str(chain/'producer-chain-readonly'),str(new)) for x in cmd]
cmd[cmd.index('--name')+1]='forge-correspondence-observer-producer-20261103-0001'
run('producer-chain',cmd,0)
for case in ['baseline','register-interference']:
 folder=OUT/case;folder.mkdir(exist_ok=False)
 output=folder/'capture';output.mkdir()
 commands=(OLD/'commands.gdb').read_text()
 if case=='register-interference':
  commands=commands.replace('continue\nprintf "FORGE_GUEST_EXIT=',
   'hbreak *0x1117c\ncontinue\nprintf "FORGE_BEFORE_A2=%d\\n", $a2\nset $a2 = 22\nprintf "FORGE_AFTER_A2=%d\\n", $a2\ncontinue\nprintf "FORGE_GUEST_EXIT=')
  commands=commands.replace('if $_exitcode != 0','if $_exitcode != 2')
 (folder/'commands.gdb').write_text(commands)
 cmd=json.loads((OLD/'capture-invocation.json').read_text())['argv']
 cmd[cmd.index('--name')+1]='forge-correspondence-'+case+'-20261103-0001'
 cmd=[x.replace(str(OLD/'capture'),str(output)).replace(str(OLD/'commands.gdb'),str(folder/'commands.gdb')) for x in cmd]
 run(case,cmd,0 if case=='baseline' else 1)
 qemu=json.loads((output/'qemu-command.json').read_text())
 assert qemu['actual_exit']==(0 if case=='baseline' else 2)
 assert qemu['terminated_by_observer'] is False
 if case=='register-interference':
  raw=(output/'debugger.stdout').read_text()
  assert 'FORGE_BEFORE_A2=21\n' in raw and 'FORGE_AFTER_A2=22\n' in raw and 'FORGE_GUEST_EXIT=2\n' in raw
  assert 'assert code == 0' in (OUT/(case+'.log')).read_text()
 cmd=json.loads((OLD/'producer-after-command.json').read_text())['argv']
 cmd[cmd.index('--name')+1]='forge-correspondence-'+case+'-producer-post-20261103-0001'
 cmd=[x.replace(str(OLD/'capture'),str(output)) for x in cmd]
 run(case+'-producer-post',cmd,0)
(OUT/'observation-acceptance.json').write_text(json.dumps({'actual_exit':0,'baseline_guest_exit':0,'interfered_guest_exit':2,'interfered_observer_exit':1,'reason':'Existing zero-exit assertion rejects actual register interference','model_changed':False,'proof_changed':False,'runtime_refinement':'NOT_ESTABLISHED','end_to_end':False},indent=2)+'\n')
