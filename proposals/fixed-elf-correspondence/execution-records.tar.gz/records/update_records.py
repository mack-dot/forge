"""Append current observations. Preserve the complete old uncertainty journal."""
import hashlib,json
from pathlib import Path
ROOT=Path('/Users/mackianni/forge'); OUT=Path(__file__).resolve().parent
k=json.loads((OUT/'kernel-output/result.json').read_text())
assert k['actual_kernel_exit']==0 and k['modules']==597 and k['closure_assumptions']==86
journal=ROOT/'unsure.md'; before=journal.read_bytes()
assert b'## U254 ' not in before
entry='''

## U254 — Fixed behavior and modeled exit independently replayed; runtime transfer remains conditional

- References:U229,U247-U253. The owner authorizes continued local work and commits.
  CURRENT none;Stage12 unauthorized;end_to_end=false. No new stage or scope.
- Fresh Behavior source compilation0 reproduces objectf1d3b7e2 byte for byte.
  New ExitBridge compilation0 and separate rebuild0 reproduce objectb433ae9a.
  It conjoins fixed GCD21, the unchanged must-exit0 theorem and an explicit
  LPS ExitEv0/haltsSome0 realization using published must_exit_at_cfg_realizes.
  Model guards halted=None/lazy=[] remain. No new axiom or machine semantics.
- Complete recursive independent kernel0:597 modules, exact same86 permitted
  closure assumptions;1540.643432076 seconds. Raw logSHA34f857e07117fd417c839fee4a7df645b5bc63390c84e3bf85d45b6c8cf3db8b.
  This closes U252/U253's NOT RUN item for these new roots. Their historical
  wording remains intact. New process, same physical host; full replay, not
  -norec. Postflight0 confirms30 source identities unchanged. Object pool609
  is not the actual loaded closure count; exact loaded membership is retained.
- Fresh producer/baseline/postidentity0/0/0. Same21-frame projection,404 LOAD
  bytes, FCSR0, guest and parent exit0; observer did not kill QEMU. Actual
  debugger interference changes a2=21 to22; guest/parent2 and unchanged observer
  rejection1. Existing wrong-GCD22 and halted-model controls reject1/1; nine
  marker controls pass harness0 with one positive0 and eight negative1. Corrupt
  proof and substituted ELF reject1/1 before kernel/guest launch. Corrupt LOAD
  comparison rejects1. None of those expected negatives is a proof success.
- New exit distinction: inspected authenticated QEMU source calls gdb_exit in
  preexit_cleanup before the host exit_group. GDB notification alone cannot
  establish physical termination. Actual parent wait0 supplies a distinct finite
  observation. QEMU/Linux/observer/host fidelity and physical progress remain
  assumptions; source inspection is not a refinement or binary-build proof.
- Prepared portable proof and runtime packets with external expected hashes.
  Relocated inputs rebuild both proof objects identically0 and replay runtime0
  without mounting original worktrees. This is same-machine portability, not
  an independent physical-host test. Full kernel ran against the same held
  objects; relocated --rebuild-only is not another full replay. QEMU's held
  digest retains historical producer trust; fresh package-chain checking covers
  the413-member GDB observer tree, not a QEMU source-to-binary rebuild.
- First portable extraction failed1: host Python3.10.11 lacks tar data-filter
  support. Retained that failure and used the same standard filter in the
  existing pinned Python3.12.3 image, exit0. No filter removed/tool installed.
  All prior parser,OOM,oracle,observer and vDSO failures remain preserved.
- Effective rules/ruleset exports0: independent review protections present,
  no required status checks/workflows. Classic protection endpoint1/HTTP404;
  effective rules obtained separately. No governance change. Mainf9 and PR37
  exactfc85 remain unchanged;PR37 draft/open/unmerged/no reviews. PR36 separate.
- Original archives validate0 and actual local restore0:10160 members each,
  zero hash mismatches. Existing local Git bundle verifies0. Owner's other-
  device copy remains reported; exact location, remote archive hashes and restore
  are NOT RUN. Existing strict integration EXIT1 has only the backup flag false.
  Old bundle excludes latest commits; old archives exclude the new evidence.
- Evidence:results/executable-correspondence-2026-11-03/attempt-0001/{REPORT.md,
  CORRESPONDENCE.md,APPROVAL-PACKET.md,assurance-result.json,kernel-output/,
  observation-commands.json,identity-controls.json,relocated-replay-commands.json,
  local-restore-result.json,integration-exit-command.json}. Exact argv and raw
  logs retained. Proofpacket3ae40b4c...;runtimepacket55eec1b9....
- Verdict PARTIALLY_ESTABLISHED. The fixed result is intermediate a0=21 for
  inputs1071/462, not arbitrary-input GCD or output21. Finite projected embedding
  does not prove complete concrete state or every QEMU successor. Physical
  pending/Model applicability, instruction/capture fidelity, noninterference,
  Linux exit meaning and universal progress remain explicit reviewed conditions.
- Next boundary: exact conditional contract/profile proposal at
  proposals/fixed-elf-correspondence/, plus independent review of the separate
  proof/observer supplement. Protected spec patch is unapplied and passes only
  apply --check. No policy, producer, workflow or signed claim was changed.
  Fresh authorized provenance and independent admission remain NOT RUN. Local
  commit authorization does not authorize publication/adoption/merge/dispatch/
  signing/admission/deployment. Keep all six T1-T6 trust conditions explicit.
'''
with journal.open('ab') as f:f.write(entry.encode())
after=journal.read_bytes(); assert after[:len(before)]==before
record={'old_unsure_bytes':len(before),'old_unsure_sha256':hashlib.sha256(before).hexdigest(),
        'prefix_preserved':True,'new_entry':'U254','end_to_end':False}
(OUT/'journal-prefix.json').write_text(json.dumps(record,indent=2)+'\n')
section='''

## Executable correspondence closure — 2026-11-03 (U254)

CURRENT none; Stage12 unauthorized; end_to_end=false. Detailed evidence and
exact argv: results/executable-correspondence-2026-11-03/attempt-0001/REPORT.md.
Verdict PARTIALLY_ESTABLISHED. The full behavioral kernel gap from U252 is closed.
Complete physical refinement, new claim approval/provenance/admission remain open.

| Actual command / child execution | Exit | Actual result |
| --- | ---: | --- |
| `python3 -B .../prepare_and_check.py` |0|Fresh Behavior/ExitBridge compile0/0; complete recursive kernel0;597 modules,86 assumptions |
| `python3 -B .../observe_controls.py` |0|Baseline guest/parent0;404 LOAD bytes; injected-register guest2 and observer1 expected |
| `python3 -B .../recheck_controls.py` |0|ExitBridge identical rebuild0; wrong-GCD/halt1/1 expected;9 marker cases matched |
| `python3 -B .../identity_controls.py` |0|Corrupt proof/substituted ELF1/1 expected before execution |
| Relocated `replay-packet/replay.py --rebuild-only` |0|Two identical objects; full recursive check not repeated here |
| Relocated `runtime-packet/replay.py` |0|Fresh producer/baseline/postidentity0; original worktrees not mounted |
| Host Python3.10 tar extraction |1|Unsupported data-filter argument; failure preserved |
| Pinned Python3.12.3 extraction with same data filter |0|No filter removed or installation |
| `python3 -B .../operational_audit.py` |0|Read-only effective rules obtained; classic protection HTTP404 child1; no required checks |
| Original archive validation / `restore_existing_backup.py` |0/0|10160 members each; local restore only |
| Existing strict integration status |1|Only off_machine_backup_confirmed false; owner report retained |
| `python3 -B .../finalize.py` |0|Actual records agree; end_to_end=false |

The new bridge source4aeaf560... / objectb433ae9a... makes the existing modeled
exit event explicit. Result21 is the fixed1071/462 GCD in intermediate a0.
Parent wait confirms physical exit0 in this run; GDB notification alone cannot.
No universal QEMU/Linux refinement or physical progress proof is claimed.

The exact conditional claim/profile and unapplied spec patch are prepared for
review. PR37fc85 stays draft/unreviewed; mainf9 unchanged; PR36 separate. No
publication, signing, admission, merge or dispatch. Required external backup
hash/restore test awaits the existing copy's location. Local packet relocation
and archive restore are not an off-machine verification. All old failures remain.
'''
road=ROOT/'ROADMAP.md'; content=road.read_text()
head=content.splitlines()[2]
content=content.replace(head,head.replace('see U253','fresh fixed-behavior and modeled-exit kernel597 passed; see U254'),1)
road.write_text(content+section)
note='''

## New executable correspondence result — U254

The fresh full recursive independent replay passed597 modules with exactly the
same86 allowed assumptions. Behavior and explicit ExitEv0 proofs rebuilt byte
for byte. This supersedes the earlier new-root NOT RUN status, without changing
the historical record. The new runtime observation matches21 frames and404 LOAD
bytes. Parent process exit is0. Register interference produces exit2 and refusal1.

The precise field matrix, replay evidence and inactive approval packet are in
results/executable-correspondence-2026-11-03/attempt-0001/REPORT.md and its linked
CORRESPONDENCE.md. Overall PARTIALLY_ESTABLISHED; end_to_end=false. Full physical
state refinement and new authenticated release admission remain unestablished.
The next boundary is exact conditional claim/profile and independent source
review. No Stage12, accepted-policy change, publication, merge or dispatch.
The owner reports an off-machine backup. Its exact hashes/restore remain NOT RUN;
fresh local restore0 does not close strict integration EXIT1.
'''
for name in ['VERTICAL_SLICE_STATUS.md','FORGE_CURRENT_STATE_AND_PLAN.md']:
 p=ROOT/name; old=p.read_text(); p.write_text(old+note)
print(json.dumps({'actual_exit':0,'journal_prefix_preserved':True,'entry':'U254'}))
