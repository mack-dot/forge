"""Replay existing proof refusals and observation controls; no new oracle."""
import hashlib,json,shutil,subprocess
from pathlib import Path
ROOT=Path('/Users/mackianni/forge');OUT=Path(__file__).resolve().parent
rows=[]
def run(label,cmd,expected):
 with (OUT/(label+'.log')).open('xb') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 rows.append({'case':label,'argv':cmd,'actual_exit':p.returncode,'expected_exit':expected})
 (OUT/'control-commands.json').write_text(json.dumps(rows,indent=2)+'\n')
 assert p.returncode==expected,label
 print(label+': '+str(p.returncode),flush=True)

for label,old,source in [
 ('wrong-gcd',ROOT/'results/vertical-slice-audit-2026-11-03/attempt-0001/negative-command.json','WrongGcd.v'),
 ('halted-model',ROOT/'results/runtime-process-prefix-2026-11-03/attempt-0002/negative-halted-command.json','WrongHalt.v')]:
 cmd=json.loads(old.read_text())['argv'];folder=OUT/label;folder.mkdir(exist_ok=False)
 cmd[cmd.index('--name')+1]='forge-correspondence-'+label+'-20261103-0001'
 for i,arg in enumerate(cmd):
  if arg.startswith('type=bind') and 'target=/trial' in arg:
   source_folder=Path(arg.split('source=')[1].split(',')[0]);shutil.copyfile(source_folder/source,folder/source)
   cmd[i]=arg.replace(str(source_folder),str(folder))
 run(label,cmd,1)
 assert ('22%Z' if label=='wrong-gcd' else 'm_halted model = None') in (OUT/(label+'.log')).read_text()

old=ROOT/'results/fixed-elf-observer-2026-11-03/attempt-0002'
prior=json.loads((OUT/'baseline-producer-post.log').read_text())
assert prior['members']==413
inv=json.loads((ROOT/'results/fixed-elf-observer-2026-11-03/attempt-0003/producer-after-command.json').read_text())['argv']
cmd=inv[:inv.index('--mount')];cmd[cmd.index('--name')+1]='forge-correspondence-marker-controls-20261103-0001'
out=OUT/'marker-controls';out.mkdir(exist_ok=False)
for src,dst,ro in [(old,'/code',True),(OUT/'baseline/capture','/original',True),(out,'/records',False)]:
 cmd+=['--mount','type=bind,source='+str(src)+',target='+dst+(',readonly' if ro else '')]
cmd += [inv[inv.index('python3')-1],'python3','-I','-S','-B','/code/check_markers.py']
run('marker-controls',cmd,0)

original=OUT/'bridge/ExitBridge.v';second=OUT/'bridge-rebuild';second.mkdir(exist_ok=False)
shutil.copyfile(original,second/original.name)
cmd=json.loads((OUT/'exit-bridge-command.json').read_text())['argv']
cmd=[x.replace(str(OUT/'bridge'),str(second)) for x in cmd]
cmd[cmd.index('--name')+1]='forge-correspondence-exit-bridge-repeat-20261103-0001'
run('bridge-rebuild',cmd,0)
assert (second/'ExitBridge.vo').read_bytes()==(OUT/'bridge/ExitBridge.vo').read_bytes()
(OUT/'bridge-reproduction.json').write_text(json.dumps({'actual_exit':0,'source_sha256':hashlib.sha256(original.read_bytes()).hexdigest(),'object_sha256':hashlib.sha256((second/'ExitBridge.vo').read_bytes()).hexdigest(),'byte_identical':True},indent=2)+'\n')
