"""Finalize only from actual terminal checker and observation records."""
import hashlib,json,re
from pathlib import Path
ROOT=Path('/Users/mackianni/forge');OUT=Path(__file__).resolve().parent
def read(name):return json.loads((OUT/name).read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
k=read('kernel-output/result.json')
assert k['result']=='PASSED' and k['actual_kernel_exit']==0
assert read('full-kernel-command.json')['actual_exit']==0
assert read('source-postflight.json')['actual_exit']==0
prior=json.loads((ROOT/'results/runtime-process-prefix-kernel-2026-11-03/attempt-0001/kernel-output/actual-assumptions.json').read_text())
assert read('kernel-output/actual-assumptions.json')==prior
raw=(OUT/'kernel-output/independent-kernel.log').read_text()
modules=re.findall(r'^Checking library: (.+)$',raw,re.M)
assert len(modules)==len(set(modules))==k['modules']
assert {'ForgeSlice.Behavior','ForgeExitBridge.ExitBridge'}<=set(modules)
assert read('observation-acceptance.json')['actual_exit']==0
assert read('identity-controls.json')['actual_exit']==0
assert read('packet-rebuild/result.json')['byte_identical_rebuilds']==2
assert all(x['actual_exit']==0 for x in read('relocated-replay-commands.json'))
assert read('relocated-trace-binding.json')['matching_recorded_frame_prefix']
baseline=read('baseline/capture/result.json')
assert baseline['qemu_exit']==baseline['gdb_exit']==0
assert read('integration-exit.json')['blockers']==['off_machine_backup_confirmed']
facts={'verdict':'PARTIALLY_ESTABLISHED','end_to_end':False,'current_stage':None,
       'stage12_authorized':False,'kernel':k,'actual_module_names':modules,
       'actual_closure_sha256':sha(OUT/'kernel-output/actual-closure-identities.json'),
       'assumption_list_sha256':sha(OUT/'kernel-output/actual-assumptions.json'),
       'behavior':read('reproduction.json'),'exit_bridge':read('bridge-reproduction.json'),
       'portable_archives':read('portable-archives.json'),
       'new_claim_approved':False,'new_signature':'NOT RUN','new_admission':'NOT RUN',
       'independent_physical_machine_replay':'NOT RUN','remote_backup_restore':'NOT RUN',
       'runtime_assumptions':['T1','T2','T3','T4','T5','T6']}
(OUT/'assurance-result.json').write_text(json.dumps(facts,indent=2,sort_keys=True)+'\n')
profile={'status':'PROPOSED_NOT_ACTIVE','contract_sha256':sha(ROOT/'proposals/fixed-elf-correspondence/contract.md.proposed'),
 'elf_sha256':'8ced2ab6c7160338899056fe51bacb23d86d81705eacfdd1e992cf5252bdaeb6',
 'behavior_source_sha256':facts['behavior']['source_sha256'],'behavior_object_sha256':facts['behavior']['object_sha256'],
 'bridge_source_sha256':facts['exit_bridge']['source_sha256'],'bridge_object_sha256':facts['exit_bridge']['object_sha256'],
 'theorem_names':['ForgeSlice.Behavior.fixed_pair_gcd','ForgeSlice.Behavior.exact_loop_pairs','ForgeSlice.Behavior.loop_result_is_fixed_pair_gcd','ForgeSlice.Behavior.observed_machine_must_exit_zero','ForgeExitBridge.ExitBridge.fixed_behavior_and_model_exit_holds'],
 'proof_packet_sha256':facts['portable_archives'][0]['sha256'],
 'checker_image':'ghcr.io/theorem-labs/oss-fuzz-theorems-checker@sha256:cc9ae43a9f4b0dd59d7c8d30727d36e039bfe72a2a9f9c4a99c68e413037e902',
 'actual_closure_sha256':facts['actual_closure_sha256'],'assumption_list_sha256':facts['assumption_list_sha256'],
 'kernel_modules':k['modules'],'closure_assumptions':k['closure_assumptions'],
 'qemu_sha256':'be89e201dc6112ef101617ab575c95119ad123f80ca2b51b6c36ef218ac9df65',
 'gdb_sha256':'0baeb299d3aa39f40ca72c3cb8ae5b15a5bd01f1995583a52cfdd7527bfffe07',
 'runtime_packet_sha256':facts['portable_archives'][1]['sha256'],
 'observed_trace_sha256':read('trace-binding.json')['new_trace_sha256'],
 'observed_runtime_host':{'docker':'28.5.1','server_architecture':'arm64','kernel_version':'6.10.14-linuxkit','container_platform':'linux/amd64','host_translation_verified':False},
 'runtime_conditions':['T1','T2','T3','T4','T5','T6'],'end_to_end':False,
 'new_authoritative_producer_receipt':None,'acceptance_policy_modified':False}
(ROOT/'proposals/fixed-elf-correspondence/profile.json.proposed').write_text(json.dumps(profile,indent=2,sort_keys=True)+'\n')
report=f'''# Forge executable assurance report

CURRENT none. Stage12 unauthorized. Overall verdict: **PARTIALLY_ESTABLISHED**.
`end_to_end=false`. Complete accepted executable assurance: **NOT_ESTABLISHED**.

The new full independent replay passed: **{k['modules']} modules**, exactly the
previous **{k['closure_assumptions']} allowed closure assumptions**, kernel exit0.
The fixed GCD result and explicit modeled ExitEv0 are now covered by this replay.
The exact concrete observations have a finite projected embedding into the
published LPS execution. Full QEMU/Linux state refinement remains unproved.

## Actual checks in this session

| Command / execution | Actual exit | Evidence |
| --- | ---: | --- |
| `python3 -B prepare_and_check.py`: Behavior fresh rebuild |0|Byte-identical object; reproduction.json |
| Same dispatcher: ExitBridge compilation |0|Exact typed behavioral/exit conjunction |
| Same dispatcher: complete recursive Rocq check |0|{k['modules']} actual modules;{k['closure_assumptions']} assumptions;{k['wall_seconds']:.6f}s kernel wall time |
| ExitBridge separate rebuild |0|Byte-identical object; bridge-reproduction.json |
| Held-source postflight |0|All sources unchanged; source-postflight.json |
| `python3 -B observe_controls.py`: producer/baseline/postidentity |0/0/0|Ubuntu chain;413 observer members;404 LOAD bytes;guest/parent0 |
| Same dispatcher: actual register interference / postidentity |1/0|a2 changed21→22;guest/parent2;unchanged zero-exit assertion rejects |
| `python3 -B recheck_controls.py`: wrong result / halted state |1/1|Intended type mismatches; raw logs retained |
| Same dispatcher:9 existing observer marker controls |0|One positive0;eight intended refusals1 |
| `python3 -B identity_controls.py`: corrupted object / substituted ELF |1/1|Held identity refusal before kernel/guest launch |
| Baseline corrupted LOAD capture comparison |1|Expected cmp refusal; correct RO/text comparisons0/0 |
| Trace binding to original checked literals |0|458 pre-exit lines match;21 frames;intermediate a0=21 |
| Portable proof/runtime replay, relocated inputs |0/0|Two identical proof rebuilds;fresh observation;original worktrees not mounted |
| Effective rules / ruleset export |0/0|Independent review required;no required status checks/workflows |
| Classic branch-protection endpoint |1|HTTP404;effective rules were separately obtained |
| Local Git fsck and bundle verification |0|Held local commits/bundle intact;operational-commands.json |
| Original archive validation / local restore |0/0|Each archive10160 members;zero mismatches;not an off-machine test |
| Existing strict integration EXIT |1|Only off_machine_backup_confirmed remains false |

Full exact argv and stdout/stderr are in *-command.json, observation-commands.json,
control-commands.json, identity-control-commands.json, operational-commands.json
and the raw logs. Harness0 does not turn expected negative child exits into0.
All local commands ran on this machine. New hosted execution is NOT RUN.

## Identities

- ELF: `{profile['elf_sha256']}`.
- Behavior source/object: `{profile['behavior_source_sha256']}` / `{profile['behavior_object_sha256']}`.
- ExitBridge source/object: `{profile['bridge_source_sha256']}` / `{profile['bridge_object_sha256']}`.
- Full kernel log: `{k['kernel_log_sha256']}`.
- Actual closure manifest: `{facts['actual_closure_sha256']}`.
- Exact assumption list: `{facts['assumption_list_sha256']}`.
- Fresh runtime trace: `{profile['observed_trace_sha256']}`.

The anchored input pool can contain more objects than the actual checked closure.
The module names and loaded dependency digests, not just counts, are retained.
The unchanged checker recursively checks all imports; no -norec or axiom waiver.

## Claim boundary and shortest remaining path

Read CORRESPONDENCE.md for the full A/B/C/D distinction and field matrix.
The fixed result21 is in a0 before termination, not stdout or arbitrary-input GCD.
Reservation/FCSR/data-memory values are quantified. Model applicability,
instruction/capture fidelity, noninterference, Linux exit meaning and physical
progress remain explicit T1–T6 conditions requiring independent review.

The highest-value next change is review of the exact conditional contract and
profile in proposals/fixed-elf-correspondence/. The non-activated spec addition
passes git apply --check; it changes no accepted policy. After intent/profile
review, prepare the narrowly scoped existing producer/consumer binding update
described in APPROVAL-PACKET.md. A fresh authorized producer must execute the
selected checks, then bind the new claim/ELF/runtime/observations to independent
admission. The historical signature authenticates only the historical release.

PR37fc85 remains draft/open/unmerged with no submitted reviews at the fresh read.
The new supplement needs separate exact review. PR36 stays independent. No
publication, merge, dispatch, signing, admission or deployment occurred.

## Reproduction and operations

The proof packet carries all host proof inputs plus the unchanged audit tools.
The runtime packet carries the held ELF/QEMU, full observer tree and signed
observer-package inputs. Both require only the existing pinned checker image
and a compatible Docker runtime. Their manifests are integrity records, not
self-authenticating provenance. Use the separately reviewed archive digest.
Relocation and rebuild/runtime replay passed locally; independent physical-host
replay remains NOT RUN. Full kernel replay ran against the same exact held
objects; the relocated packet's kernel was not redundantly rerun.

'''
for item in facts['portable_archives']:report+=f"- {item['name']}: {item['bytes']} bytes; SHA256 `{item['sha256']}`.\n"
report+='''
The70MB runtime packet stays in the owner evidence workspace, referenced by its
immutable digest. The owner reports another-device backup, but its exact archive
contents/location and restore remain unverified. Local restore success does not
close that condition. BACKUP-HANDOFF.md gives the exact independent restore step.

The first portable extraction failed1 because host Python3.10.11 lacks the
standard tar data-filter argument. The same filter ran successfully in the
existing pinned Python3.12.3 checker image. No filter was removed or tool installed.
All earlier OOM, wrong-range oracle, parser, observer-content and vDSO diagnostics
remain in the append-only evidence history. No old failure was rewritten as pass.
'''
(OUT/'REPORT.md').write_text(report)
matrix=OUT/'CORRESPONDENCE.md';text=matrix.read_text().replace('pending the\nterminal independent replay result, reviewed conditional contract and new','pending the\nreviewed conditional contract and new')
matrix.write_text(text)
print(json.dumps({'verdict':facts['verdict'],'modules':k['modules'],'axioms':k['closure_assumptions'],'kernel_exit':0,'end_to_end':False}))
