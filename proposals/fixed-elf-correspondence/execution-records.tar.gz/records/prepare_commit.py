"""Prepare review-only files and lossless records in an isolated local branch."""
import gzip,hashlib,json,shutil,subprocess,tarfile
from pathlib import Path
ROOT=Path('/Users/mackianni/forge'); OUT=Path(__file__).resolve().parent
WT=Path('/private/tmp/forge-correspondence-review-20261103')
DEST=WT/'proposals/fixed-elf-correspondence'
assert not DEST.exists()
assert subprocess.check_output(['git','-C',str(WT),'status','--porcelain'])==b''
assert json.loads((OUT/'assurance-result.json').read_text())['kernel']['actual_kernel_exit']==0
DEST.mkdir(parents=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def copy(src,rel):
 p=DEST/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,p)
for name in ['REPORT.md','CORRESPONDENCE.md','APPROVAL-PACKET.md','BACKUP-HANDOFF.md',
             'assurance-result.json','replay-packet.tar.gz','portable-archives.json']:
 copy(OUT/name,name)
for p in sorted((ROOT/'proposals/fixed-elf-correspondence').iterdir()):
 if p.is_file():copy(p,p.name)
copy(OUT/'rebuild/Behavior.v','source/Behavior.v')
copy(OUT/'bridge/ExitBridge.v','source/ExitBridge.v')
for folder in ['replay-packet','runtime-packet']:
 for name in ['README.md','replay.py','manifest.json']:
  p=OUT/folder/name
  if p.exists():copy(p,folder+'/'+name)
 if folder=='runtime-packet':copy(OUT/folder/'commands.json',folder+'/commands.json')
for name in ['restore_existing_backup.py','check_archives.py']:
 copy(OUT/name,'backup/'+name)
cmd=['git','-C','/private/tmp/forge-campaign-main-20261102','apply','--check',str(ROOT/'proposals/fixed-elf-correspondence/contract.patch')]
r=subprocess.run(cmd,capture_output=True)
record={'argv':cmd,'actual_exit':r.returncode,'stdout':r.stdout.decode(),'stderr':r.stderr.decode(),
        'patch_sha256':sha(ROOT/'proposals/fixed-elf-correspondence/contract.patch'),'applied':False}
(OUT/'contract-check.json').write_text(json.dumps(record,indent=2)+'\n');assert r.returncode==0
files=set()
suffixes={'.json','.py','.log','.stdout','.stderr','.md'}
for p in OUT.iterdir():
 if p.is_file() and p.suffix in suffixes:files.add(p)
for name in ['kernel-output','baseline','register-interference','marker-controls',
             'corrupt-proof-kernel-output','wrong-gcd','halted-model','packet-rebuild',
             'bridge-rebuild','rebuild','bridge']:
 for p in (OUT/name).rglob('*'):
  if p.is_file():files.add(p)
for parent in [OUT/'producer-chain',OUT/'portable-runtime-replay',OUT/'portable-runtime-replay/producer-chain']:
 for p in parent.iterdir():
  if p.is_file() and p.suffix in suffixes:files.add(p)
for p in (OUT/'portable-runtime-replay/capture').rglob('*'):
 if p.is_file():files.add(p)
manifest=[]
archive=DEST/'execution-records.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w',format=tarfile.PAX_FORMAT) as tf:
   for p in sorted(files):
    assert not p.is_symlink()
    rel=p.relative_to(OUT).as_posix()
    manifest.append({'path':rel,'bytes':p.stat().st_size,'sha256':sha(p)})
    info=tf.gettarinfo(str(p),arcname='records/'+rel)
    info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0;info.mode=0o644
    with p.open('rb') as f:tf.addfile(info,f)
(DEST/'records-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(archive,'r:gz') as tf:
 for row in manifest:
  content=tf.extractfile('records/'+row['path']).read()
  assert len(content)==row['bytes'] and hashlib.sha256(content).hexdigest()==row['sha256']
readme='''# Fixed ELF correspondence — local review supplement

Current stage: none. Stage12 remains unauthorized. `end_to_end=false`.
Status: PARTIALLY_ESTABLISHED. No new claim or profile is active.

The fixed-input GCD result and modeled exit event passed a fresh full recursive
Rocq replay:597 modules,86 permitted closure assumptions. The actual QEMU run
matches the checked projection and exits0. Complete QEMU/Linux refinement and
new authenticated release admission remain unestablished.

Read REPORT.md, CORRESPONDENCE.md and APPROVAL-PACKET.md. The latter states the
exact conditional claim, six trust conditions and independent review boundaries.
The source files are review copies. `contract.patch` is unapplied; its validation
only checked that it applies. `profile.json.proposed` is inactive.

## Reproduce and inspect

Authenticate these archive digests against the separately reviewed commit before
extracting or running anything. In-archive manifests do not authenticate themselves.
Use the existing pinned checker image and resource limits. No installation or
new persistent infrastructure is required. The original runtime/checker trust
conditions remain; these packets do not replace independent source review.

- `replay-packet.tar.gz` contains all host proof inputs and the existing checker.
  Its README describes a fresh two-object rebuild followed by full kernel replay.
  `--rebuild-only` explicitly omits kernel replay.
- `execution-records.tar.gz` contains the actual records under `records/`.
  Report-relative evidence paths refer to that directory after extraction.
  `records-manifest.json` preserves every archived file's digest and size.
- The70MB runtime packet remains in the owner evidence workspace. Its digest is
  below and in portable-archives.json. The runtime-packet directory here contains
  review copies of its entry point/manifest only; it is not the complete runtime.
  Obtain the complete archive and authenticate its digest before running it.
  Local packet relocation passed. Independent physical-host replay is NOT RUN.

Complete runtime archive in the owner workspace:
`/Users/mackianni/forge/results/executable-correspondence-2026-11-03/attempt-0001/runtime-packet.tar.gz`.

'''
for p in [DEST/'replay-packet.tar.gz',DEST/'execution-records.tar.gz',OUT/'runtime-packet.tar.gz']:
 readme+=f'- `{p.name}`: SHA256 `{sha(p)}`; {p.stat().st_size} bytes.\n'
readme+='''
PR37 stays at fc85ecc2c7f12caa6c8991fa002410bdf78dd51d, draft and unapproved.
This supplement is separate from that head. PR36's upload repair is separate.
Publication, claim/profile adoption, protected integration changes, merge,
dispatch, signing, admission and deployment retain their approval boundaries.
The owner reports an independent backup; its exact hashes/restore remain unverified.
See BACKUP-HANDOFF.md. Local archive validation and restore both passed.
'''
(DEST/'README.md').write_text(readme)
all_files=[{'path':p.relative_to(DEST).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)}
           for p in sorted(DEST.rglob('*')) if p.is_file()]
(DEST/'review-manifest.json').write_text(json.dumps(all_files,indent=2)+'\n')
result={'actual_exit':0,'destination':str(DEST),'archive_members':len(manifest),
        'all_archived_bytes_match':True,'review_files':len(all_files)+1,
        'protected_paths_modified':False,'end_to_end':False}
(OUT/'commit-preparation.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
