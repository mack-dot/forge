(* Deliberately false guard substitution. Required refusal; never accepted. *)
From Stdlib Require Import ZArith List Lia.
From LinuxProcessSemantics.LinuxProcessSem Require Import BvBase RiscvSemantics State Run.
From LinuxProcessSemantics.LinuxProcessSem.Checks Require Import Omni.
Require ForgeObserved.ObservedTransitions.
Require ForgeProcessPrefix.ProcessPrefix.
From Forge.Binary.images Require Program.
Import ListNotations.
Module O := ForgeObserved.ObservedTransitions.
Module G := Program.M.

Lemma halted_model_can_take_the_first_instruction :
 forall rnd argv envp uid hw mem resv fcsr model cfg,
 m_halted model = Some (Z_to_bv 64 0) ->
 exists current next,
 run_steps 0 G.loaded_segments
  (O.observed_initial_machine rnd argv envp uid hw mem resv fcsr) = Some current /\
 run_steps 1 G.loaded_segments
  (O.observed_initial_machine rnd argv envp uid hw mem resv fcsr) = Some next /\
 sstep_cfg G.loaded_segments cfg (mkCfg current model) []
  (SNext (mkCfg next model)).
Proof.
 intros rnd argv envp uid hw mem resv fcsr model cfg Hhalt.
 eapply ForgeProcessPrefix.ProcessPrefix.every_recorded_instruction_is_a_process_step.
 - exact Hhalt.
 - lia.
Qed.
