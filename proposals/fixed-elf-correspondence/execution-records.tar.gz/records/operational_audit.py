"""Read-only GitHub controls, local recovery and runtime identity audit."""
import hashlib,json,os,subprocess
from pathlib import Path
OUT=Path(__file__).resolve().parent
records=[]
def run(name,argv,env=None,cwd=None):
 p=subprocess.run(argv,env=env,cwd=cwd,capture_output=True,text=True)
 (OUT/(name+'.stdout')).write_text(p.stdout)
 (OUT/(name+'.stderr')).write_text(p.stderr)
 records.append({'name':name,'argv':argv,'cwd':str(cwd) if cwd else None,'actual_exit':p.returncode})
 (OUT/'operational-commands.json').write_text(json.dumps(records,indent=2)+'\n')
 return p
token=subprocess.check_output(['gh','auth','token','--user','mack-dot','--hostname','github.com'],text=True).strip()
env=dict(os.environ,GH_TOKEN=token)
for name,suffix in [('effective-rules','rules/branches/main'),('rulesets','rulesets?includes_parents=true'),('classic-protection','branches/main/protection'),('main-commit','commits/main')]:
 run(name,['gh','api','repos/mack-dot/forge/'+suffix],env=env)
summary={'settings_changed':False,'bypass_used':False,'read_only':True,'end_to_end':False}
rules=json.loads((OUT/'effective-rules.stdout').read_text())
summary.update(effective_rule_types=[r['type'] for r in rules],required_status_checks_present=any(r['type']=='required_status_checks' for r in rules),required_workflows_present=any(r['type']=='workflows' for r in rules))
for rule in json.loads((OUT/'rulesets.stdout').read_text()):
 run('ruleset-'+str(rule['id']),['gh','api','repos/mack-dot/forge/rulesets/'+str(rule['id'])],env=env)
run('worktrees',['git','worktree','list','--porcelain'],cwd='/private/tmp/forge-campaign-main-20261102')
for name,path in [('docs','/private/tmp/forge-readiness-docs-20261103'),('observer','/private/tmp/forge-observer-review-20261103')]:
 run(name+'-head',['git','rev-parse','HEAD'],cwd=path)
 run(name+'-fsck',['git','fsck','--full','--no-reflogs'],cwd=path)
 run(name+'-status',['git','status','--porcelain'],cwd=path)
bundle=Path('/Users/mackianni/forge-backups/forge-readiness-commits-2026-11-03.bundle')
assert hashlib.sha256(bundle.read_bytes()).hexdigest()=='f9ad6a46f892b204ea12b38bea12b971e0e4dc72e7b50f5dd0ec0fe5ee9a4ee6'
run('bundle-verify',['git','bundle','verify',str(bundle)],cwd='/private/tmp/forge-campaign-main-20261102')
run('docker-version',['docker','version','--format','{{json .}}'])
run('baseline-container',['docker','inspect','forge-correspondence-baseline-20261103-0001'])
summary.update(owner_reports_backup_on_other_device=True,remote_archive_hash_check='NOT RUN',remote_restore='NOT RUN',remote_location='AWAITING OWNER DETAILS',local_bundle_integrity=True,local_bundle_contains_latest_commits=False)
(OUT/'operational-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary))
