"""oft generate: deterministic, complete, and checked; and the schemas under it."""
import os
import shutil
import unittest

from oft import facts, generate, rocq, schema, shapes, yamlio
from oft.tests.helpers import tree


class Rendering(unittest.TestCase):
    def test_deterministic(self):
        with tree() as a, tree() as b:
            ra = generate.render_all(facts.load(a.root))
            rb = generate.render_all(facts.load(b.root))
            self.assertEqual(ra, rb)
            self.assertEqual(generate.render_all(facts.load(a.root)), ra)

    def test_check_passes_on_a_rendered_tree(self):
        with tree() as t:
            self.assertEqual(t.generate(check=True), 0, t.last_output)

    def test_a_hand_edit_fails_the_check(self):
        with tree() as t:
            t.write("projects/zlib/checksum_fuzzer/Statements.v", "(* an edit *)\n", "a")
            self.assertEqual(t.generate(check=True), 1)
            self.assertIn("differs from its rendering", t.last_output)

    def test_a_facts_change_without_its_rendering_fails(self):
        with tree() as t:
            y = t.yaml("projects/zlib/checksum_fuzzer/harness.yaml")
            y["statements"]["asan_agrees"]["budgets"] = "standard"
            t.put_yaml("projects/zlib/checksum_fuzzer/harness.yaml", y)
            self.assertEqual(t.generate(check=True), 1)
            self.assertIn("projects/zlib/checksum_fuzzer/Statements.v: differs", t.last_output)

    def test_a_stale_generated_file_fails(self):
        with tree() as t:
            t.write("projects/json/fuzzer-parse_bjdata/Characterise.v", "(* left over *)\n")
            self.assertEqual(t.generate(check=True), 1)
            self.assertIn("no longer produce", t.last_output)

    def test_a_distribution_header_edit_fails(self):
        with tree() as t:
            p = "projects/zlib/checksum_fuzzer/Distribution.v"
            t.write(p, t.read(p).replace("mean 4,096", "mean 4,097"))
            self.assertEqual(t.generate(check=True), 1)

    def test_bad_facts_render_nothing(self):
        with tree() as t:
            t.write("projects/zlib/project.yaml", "extra: 1\n", "a")
            self.assertEqual(t.generate(), 1)
            self.assertIn("nothing rendered", t.last_output)


class StatementText(unittest.TestCase):
    def test_zlib_checksum_fuzzer(self):
        with tree() as t:
            s = t.read("projects/zlib/checksum_fuzzer/Statements.v")
        self.assertIn("Definition plain_halts : Prop :=\n  halts_within_budget Budgets.Standard.lim_source "
                      "Exits.ok_or_refused Images.plain.", s)
        self.assertIn("Definition plain_halts_may_fail : Prop :=\n  halts_may_fail Exits.any Images.plain.", s)
        self.assertIn("Definition asan_agrees : Prop :=\n  agrees Budgets.Asan.lim_source Budgets.Asan.lim_target "
                      "Images.plain Images.asan.", s)
        self.assertIn("Definition ubsan_agrees : Prop :=\n  agrees Budgets.Standard.lim_source "
                      "Budgets.Standard.lim_target Images.plain Images.ubsan.", s)
        self.assertIn("Definition asan_disagrees_at_most (b : Q) : Prop :=\n  disagrees_at_most Env.may_fail "
                      "Distribution.w Distribution.M Images.plain Images.asan b.", s)
        self.assertIn("From OssFuzzTheorems.zlib.checksum_fuzzer Require Images Distribution.", s)
        self.assertNotIn("Admitted", s)
        self.assertEqual(s.count("(*"), s.count("*)"))

    def test_a_may_fail_halts_statement_is_not_called_stronger_than_the_budget_one(self):
        """halts_may_fail with Exits.any does not imply halts_within_budget with exits 0 and 2: an exit with
        status 77 or 78 satisfies the first and falsifies the second."""
        with tree() as t:
            s = " ".join(t.read("projects/zlib/checksum_fuzzer/Statements.v").split())
        self.assertIn("It covers every input and any refusal, unlike [plain_halts], but allows any exit status.", s)
        self.assertIn("It covers every input and any refusal, unlike [ubsan_halts], but allows any exit status.", s)
        self.assertNotIn("stronger than", s)

    HALTS_BUDGET = ("plain_halts", "ubsan_halts", "asan_halts", "asan_ubsan_halts")

    def rejecting(self, t, exits=(0, 2, 78), rejects=True):
        p = "projects/zlib/checksum_fuzzer/harness.yaml"
        y = t.yaml(p)
        if rejects:
            y["rejects"] = [{"where": "source/checksum_fuzzer.c:10-12", "what": "A short input is returned 1."}]
        for n in self.HALTS_BUDGET:
            y["statements"][n]["exits"] = list(exits)
        t.put_yaml(p, y)

    def test_a_harness_that_rejects_allows_78(self):
        with tree() as t:
            self.rejecting(t)
            self.assertEqual(t.generate(), 0, t.last_output)
            s = t.read("projects/zlib/checksum_fuzzer/Statements.v")
            r = t.read("projects/zlib/checksum_fuzzer/README.md")
        self.assertIn("Definition plain_halts : Prop :=\n  halts_within_budget Budgets.Standard.lim_source "
                      "(cons (stdpp.bitvector.definitions.Z_to_bv _ 78%Z) Exits.ok_or_refused) Images.plain.", s)
        self.assertIn("Status 78 is", s)
        self.assertIn("Definition plain_halts_may_fail : Prop :=\n  halts_may_fail Exits.any Images.plain.", s)
        self.assertIn("returning a value other than 0 or -1", r)
        self.assertIn("([lines 10-12](source/checksum_fuzzer.c#L10-L12))", r)

    def test_78_goes_with_rejects_both_ways(self):
        for exits, rejects in (((0, 2), True), ((0, 2, 78), False)):
            with tree() as t:
                self.rejecting(t, exits, rejects)
                self.assertEqual(t.generate(), 1)
                self.assertIn("exits include 78 exactly when the harness lists rejects", t.last_output)

    def test_a_rejecting_project_page_names_78(self):
        with tree() as t:
            self.rejecting(t)
            self.assertEqual(t.generate(), 0, t.last_output)
            self.assertIn("0, 2 or 78", t.read("projects/zlib/README.md"))

    def test_mixed_exit_sets_keep_apart(self):
        """A statement is written "As [first]" only after one with the same exit
        set, and the project page names an exit set other than the commonest."""
        p = "projects/zlib/checksum_fuzzer/harness.yaml"
        with tree() as t:
            self.rejecting(t)
            y = t.yaml(p)
            y["statements"]["asan_halts"]["exits"] = "any"
            t.put_yaml(p, y)
            self.assertEqual(t.generate(), 0, t.last_output)
            s = t.read("projects/zlib/checksum_fuzzer/Statements.v")
            page = t.read("projects/zlib/README.md")
        ubsan = s[s.index("Definition plain_halts :"):s.index("Definition ubsan_halts :")]
        asan = s[s.index("Definition ubsan_halts :"):s.index("Definition asan_halts :")]
        self.assertNotIn("As [plain_halts]", asan)
        self.assertIn("As [plain_halts]", ubsan)
        self.assertIn("any status (status 0, 2 or 78 for checksum_fuzzer)", page)

    def test_a_return_only_check_beside_rejects_is_named(self):
        """78 does not say which line returned, so a check that reports a failure by
        returning is allowed too; the page says so."""
        p = "projects/zlib/checksum_fuzzer/harness.yaml"
        with tree() as t:
            self.rejecting(t)
            y = t.yaml(p)
            y["checks"] = [{"kind": "invariant", "strength": "weak", "stops_with": "return-only", "live": "unknown",
                            "where": "source/checksum_fuzzer.c:10-11", "what": "A failed round trip returns 1."}]
            for s in y["statements"].values():
                if "binds_checks" in s:
                    s["binds_checks"] = False
            t.put_yaml(p, y)
            self.assertEqual(t.generate(), 0, t.last_output)
            r = t.read("projects/zlib/checksum_fuzzer/README.md")
        self.assertIn("a failure of a check above that reports it by returning (checksum_fuzzer.c:10-11) also "
                      "exits with status 78", r)

    def test_a_rejects_entry_must_point_into_the_source(self):
        p = "projects/zlib/checksum_fuzzer/harness.yaml"
        for where, msg in (("source/nope.c:1-2", "rejects[0].where names source/nope.c, which is not a source file"),
                           ("source/checksum_fuzzer.c:9000-9001", "rejects[0].where runs past the end of")):
            with tree() as t:
                self.rejecting(t)
                y = t.yaml(p)
                y["rejects"][0]["where"] = where
                t.put_yaml(p, y)
                self.assertEqual(t.generate(), 1)
                self.assertIn(msg, t.last_output)

    def test_a_pending_source_lists_no_rejects(self):
        p = "projects/zlib/checksum_fuzzer/harness.yaml"
        with tree() as t:
            self.rejecting(t)
            y = t.yaml(p)
            y["source"]["pending"] = True
            y["source"]["files"] = []
            y["checks"] = []
            for s in y["statements"].values():
                s.pop("binds_checks", None)
            t.put_yaml(p, y)
            self.assertEqual(t.generate(), 1)
            self.assertIn("checks and rejects name lines of a source that is not published", t.last_output)

    def test_characterise_and_images(self):
        with tree() as t:
            c = t.read("projects/zlib/checksum_fuzzer/Characterise.v")
            i = t.read("projects/zlib/checksum_fuzzer/Images.v")
            d = t.read("projects/zlib/checksum_fuzzer/images/dune")
        self.assertIn("Definition asan_classifies (C : Image) : Prop :=\n  classifies Env.may_fail Images.plain "
                      "Images.asan C.", c)
        self.assertIn("Lemma asan_ubsan_wf : image_wf asan_ubsan.", i)
        self.assertIn("(targets Plain.v Plain_seg_000.hex Plain_seg_001.hex Plain_seg_002.hex Plain_seg_003.hex)", d)

    def test_chunked_segments(self):
        self.assertEqual(generate.hex_targets("Plain", [1, 2]),
                         ["Plain_seg_000.hex", "Plain_seg_001_chunk_000.hex", "Plain_seg_001_chunk_001.hex"])

    def test_a_harness_name_that_is_not_an_identifier(self):
        with tree() as t:
            s = t.read("projects/json/fuzzer-parse_bjdata/Statements.v")
            dune = t.read("projects/json/fuzzer-parse_bjdata/dune")
        self.assertIn("(name OssFuzzTheorems.json.fuzzer_parse_bjdata)", dune)
        self.assertIn("agrees_in_abort_modelled Env.alloc_forced_only Budgets.Asan.lim_source", s)

    def test_a_withheld_statement_is_listed_not_stated(self):
        with tree() as t:
            s = t.read("projects/zlib/api-driver/Statements.v")
            r = t.read("projects/zlib/api-driver/README.md")
        self.assertIn("(* asan_ubsan_agrees: withheld; see README.md. *)", s)
        self.assertNotIn("Definition asan_ubsan_agrees", s)
        self.assertIn("withheld: not in this release yet", r)
        self.assertNotIn("disclosure", r)

    def test_text_is_safe_inside_a_rocq_comment(self):
        with tree() as t:
            y = t.yaml("projects/zlib/checksum_fuzzer/harness.yaml")
            y["summary"] = 'Says "hi" (* and *) leaves.'
            t.put_yaml("projects/zlib/checksum_fuzzer/harness.yaml", y)
            self.assertEqual(t.generate(), 0, t.last_output)
            s = t.read("projects/zlib/checksum_fuzzer/Statements.v")
        self.assertNotIn('"hi"', s)
        self.assertIn("( * and * )", s)

    def test_derived_statuses(self):
        with tree() as t:
            st = {s.id: s.status for s in facts.load(t.root).statements()}
            tsv = t.read("index/statements.tsv")
        self.assertEqual(st["json/fuzzer-parse_bjdata/plain_halts"], "counterexample")
        # the same run (the plain build aborts) refutes the agreement statement that names the plain build
        self.assertEqual(st["json/fuzzer-parse_bjdata/asan_agrees"], "counterexample")
        self.assertIn("json/fuzzer-parse_bjdata/plain_halts\thalts\tplain\tbudget\t0,2\tcounterexample\t"
                      "counterexamples/json/fuzzer-parse_bjdata/plain_halts\t1\t", tsv)

    def test_a_counterexample_that_exits_does_not_refute_agreement(self):
        with tree() as t:
            y = t.yaml("counterexamples/json/fuzzer-parse_bjdata/plain_halts/expect.yaml")
            y["observed"] = {"build": "plain", "exit": 77}
            t.put_yaml("counterexamples/json/fuzzer-parse_bjdata/plain_halts/expect.yaml", y)
            st = {s.id: s.status for s in facts.load(t.root).statements()}
        self.assertEqual(st["json/fuzzer-parse_bjdata/plain_halts"], "counterexample")
        self.assertEqual(st["json/fuzzer-parse_bjdata/asan_agrees"], "suspected-false")

    def test_a_witness_is_described_from_its_fields(self):
        with tree() as t:
            r = t.read("projects/zlib/checksum_fuzzer/README.md")
            k = t.read("analyses/known-issues.md")
        want = ("false (witnessed): with the input file `01 00 00 00 00 00 00`, refusing the 3rd memory request "
                "(an mmap of 4,096 bytes) makes the UBSan build end in an abort (SIGABRT) on an uncaught "
                "std::bad_alloc (run under qemu-riscv64 10.0.11)")
        self.assertIn(want, r)
        self.assertIn("zlib/checksum_fuzzer/ubsan_halts_may_fail", k)

    def test_a_statement_level_model_gap(self):
        with tree() as t:
            y = t.yaml("projects/zlib/checksum_fuzzer/harness.yaml")
            y["statements"]["plain_halts"].update(status="model-gap", gap=["vector-instructions"])
            t.put_yaml("projects/zlib/checksum_fuzzer/harness.yaml", y)
            self.assertEqual(t.generate(), 0, t.last_output)
            self.assertEqual([str(f) for f in t.lint()], [])
            r = t.read("projects/zlib/checksum_fuzzer/README.md")
        self.assertIn("blocked by the model: the binary runs RISC-V vector instructions", r)
        self.assertIn("Some statements are blocked by the model", r)

    def test_fingerprints_ignore_docstrings_but_not_bytes(self):
        with tree() as t:
            before = {s.id: s.fingerprint for s in facts.load(t.root).statements()}
            y = t.yaml("projects/zlib/checksum_fuzzer/harness.yaml")
            y["summary"] = "A different summary."
            t.put_yaml("projects/zlib/checksum_fuzzer/harness.yaml", y)
            self.assertEqual(before, {s.id: s.fingerprint for s in facts.load(t.root).statements()})
            y["builds"]["plain"]["sha256"] = "0" * 63 + "a"
            t.put_yaml("projects/zlib/checksum_fuzzer/harness.yaml", y)
            after = {s.id: s.fingerprint for s in facts.load(t.root).statements()}
        changed = sorted(k for k in before if before[k] != after[k])
        self.assertIn("zlib/checksum_fuzzer/plain_halts", changed)
        self.assertNotIn("zlib/checksum_fuzzer/ubsan_halts", changed)

    def test_the_project_pages(self):
        with tree() as t:
            z = t.read("projects/zlib/README.md")
            im = t.read("projects/imagemagick/README.md")
            top = t.read("README.md")
            status = t.read("index/STATUS.md")
        self.assertIn("1 of OSS-Fuzz's 2 fuzz targets has statements, plus an API driver", z)
        self.assertIn("**minigzip_fuzzer** (not built yet)", z)
        self.assertIn("Some builds are not in this release yet.", z)
        for word in ("disclosure", "finding", "withheld patch"):
            self.assertNotIn(word, z)
        self.assertIn("**Status: not yet built.** Needs Ghostscript in the build image. [What the statuses mean]", im)
        self.assertIn("[`zlib/checksum_fuzzer/plain_halts`]", top)
        self.assertIn("0 proved", top)
        self.assertIn("| [zlib](../projects/zlib/) | c++ | available | 1 of 2 + API driver | 8 |", status)

    def test_a_rebuild_is_invited_only_beside_a_source_bundle(self):
        """A rebuild needs the build scripts, which come with the source bundle:
        a real builder digest alone must not make the page invite one."""
        digest = "ghcr.io/theorem-labs/oss-fuzz-theorems-toolchain@sha256:" + "3" * 64
        invite = "A binary whose SHA-256 differs after a rebuild with it is a bug"
        with tree() as t:
            z = t.read("projects/zlib/README.md")       # has a source bundle
            j = t.read("projects/json/README.md")       # has none
            self.assertIn("Builder image: `%s`. %s" % (digest, invite), z)
            self.assertIn("Builder image: `%s`. These binaries cannot yet be rebuilt from this release" % digest, j)
            self.assertNotIn(invite, j)
            zero = digest.split("@")[0] + "@sha256:" + "0" * 64
            r = t.yaml("release.yaml")
            r["images"]["builder"].append(zero)
            t.put_yaml("release.yaml", r)
            y = t.yaml("projects/json/project.yaml")
            y["build"]["builder"] = zero
            t.put_yaml("projects/json/project.yaml", y)
            self.assertEqual(t.generate(), 0, t.last_output)
            j = t.read("projects/json/README.md")
            self.assertIn("Builder image: not published yet", j)
            self.assertNotIn(invite, j)

    def test_counts_agree_everywhere(self):
        """The README's counts, STATUS.md's rows and index/statements.tsv are one set of numbers."""
        with tree() as t:
            tree_ = facts.load(t.root)
            n, by, held = generate.statement_counts(tree_)
            top = t.read("README.md")
            rows = [l.split("\t") for l in t.read("index/statements.tsv").splitlines()[1:]]
            prow = [l.split("\t") for l in t.read("index/projects.tsv").splitlines()[1:]]
        self.assertEqual(len(rows), n)
        for status, k in by.items():
            self.assertEqual(sum(1 for r in rows if r[5] == status), k, status)
        self.assertIn(generate.counts_sentence(tree_), top)
        self.assertEqual(sum(int(r[9]) for r in prow), n)
        self.assertEqual(sum(int(r[15]) for r in prow), by["withheld"])

    def test_project_page_links_resolve(self):
        with tree() as t:
            for rel in ("projects/json/README.md", "projects/json/fuzzer-parse_bjdata/README.md", "README.md",
                        "analyses/known-issues.md", "index/STATUS.md"):
                import re
                base = os.path.dirname(t.path(rel))
                for target in re.findall(r"\]\(([^)#:]+)(?:#[^)]*)?\)", t.read(rel)):
                    if not any(x in target for x in ("counterexamples/", "projects/", "index/", "analyses/")):
                        continue          # docs/ and the hand-written files are not in the fixture
                    self.assertTrue(os.path.exists(os.path.normpath(os.path.join(base, target))),
                                    "%s links to %s" % (rel, target))


class Shapes(unittest.TestCase):
    def st(self, **kw):
        base = {"kind": "agreement", "builds": ["plain", "asan"], "reading": "may-fail", "budgets": "asan"}
        base.update(kw)
        return base

    def test_every_agreement_shape(self):
        want = {("may-fail", "error", "rv64g"): "agrees", ("may-fail", "signal", "rv64g"): "agrees_abort_modelled",
                ("alloc-forced-only", "error", "rv64g"): "agrees_in",
                ("alloc-forced-only", "signal", "rv64g"): "agrees_in_abort_modelled",
                ("may-fail", "error", "rv64gc"): "agrees_rv64gc",
                ("may-fail", "signal", "rv64gc"): "agrees_abort_modelled_rv64gc",
                ("alloc-forced-only", "error", "rv64gc"): "agrees_in_rv64gc"}
        for (reading, abort, machine), name in want.items():
            self.assertEqual(shapes.shape_name(self.st(reading=reading, abort=abort, machine=machine)), name)

    def test_combinations_with_no_shape_are_refused(self):
        for bad in (self.st(reading="alloc-forced-only", abort="signal", machine="rv64gc"),
                    self.st(reading="budget"), self.st(budgets=None),
                    {"kind": "halts", "builds": ["asan"], "reading": "budget", "exits": [0, 1]},
                    {"kind": "halts", "builds": ["asan"], "reading": "alloc-forced-only", "exits": "any"},
                    {"kind": "bound", "builds": ["plain", "asan"], "reading": "may-fail", "abort": "signal"}):
            bad = {k: v for k, v in bad.items() if v is not None}
            with self.assertRaises(shapes.ShapeError):
                shapes.term(bad)

    def test_rv64gc_input_set_shapes(self):
        st = {"kind": "decidability", "builds": ["plain", "asan"], "reading": "may-fail", "machine": "rv64gc"}
        self.assertEqual(shapes.shape_name(st), "agreement_decidable_rv64gc")

    def test_binding(self):
        halts = {"kind": "halts", "builds": ["plain"], "reading": "budget", "exits": [0, 2]}
        check = {"stops_with": "exit", "exit_status": 1, "live": True}
        self.assertTrue(shapes.binds(check, halts))
        self.assertFalse(shapes.binds(dict(check, exit_status=2), halts))
        self.assertFalse(shapes.binds(dict(check, live="unknown"), halts))
        self.assertFalse(shapes.binds({"stops_with": "print-only", "live": True}, halts))

    def test_a_rust_panic_is_an_exit_with_status_79(self):
        panic = {"stops_with": "panic", "live": True}
        halts = {"kind": "halts", "builds": ["plain"], "reading": "budget", "exits": [0, 2]}
        self.assertTrue(shapes.binds(panic, halts))
        self.assertFalse(shapes.binds(panic, dict(halts, reading="may-fail", exits="any")))
        self.assertFalse(shapes.binds(panic, dict(halts, exits=[0, 2, 79])))


class Code(unittest.TestCase):
    """rocq.code: what a fingerprint hashes of theories/Shapes.v and theories/Images.v."""

    def test_comments_and_blanks(self):
        self.assertEqual(rocq.code("(** doc (* nested *) *)\nDefinition  a :=\n\t0. (* end *)\n"), "Definition a := 0.")
        self.assertEqual(rocq.code("a (*c*) b\r\n(*d*)(*e*)c"), "a b c")
        self.assertNotEqual(rocq.code("a (*c*) b"), rocq.code("ab"))

    def test_a_comment_bracket_inside_a_token_is_code(self):
        """Rocq takes a declared token such as `tok(*` whole, so `tok(* 0 *)` and `tok(* 1 *)` are different code."""
        self.assertNotEqual(rocq.code("Definition t := tok(* 0 *)."), rocq.code("Definition t := tok(* 1 *)."))
        self.assertEqual(rocq.code('x."(*" "y"(* z *)'), 'x."(*" "y"(* z *)')
        self.assertEqual(rocq.code("x (* 0 *)."), rocq.code("x (* 1 *)."))

    def test_only_rocqs_blanks_are_layout(self):
        self.assertNotEqual(rocq.code("a\fb"), rocq.code("a b"))
        self.assertEqual(rocq.code("a \t\r\n b"), "a b")

    def test_a_carriage_return_in_a_string_is_code(self):
        with tree(render=False) as t:
            t.write("lf.v", 'Definition s := "a\nb".\n')
            t.write("crlf.v", 'Definition s := "a\r\nb".\r\n')
            self.assertNotEqual(facts.code_sha256(t.path("lf.v")), facts.code_sha256(t.path("crlf.v")))
            t.write("crlf.v", 'Definition s := "a\nb".\r\n')
            self.assertEqual(facts.code_sha256(t.path("lf.v")), facts.code_sha256(t.path("crlf.v")))

    def test_strings_are_code(self):
        self.assertEqual(rocq.code('Definition s := "(*  ""x""  *)".'), 'Definition s := "(*  ""x""  *)".')
        self.assertEqual(rocq.code('(* "*)" *) a'), "a")
        self.assertNotEqual(rocq.code('Definition s := "a  b".'), rocq.code('Definition s := "a b".'))

    def test_edges(self):
        """`(*)` opens a comment, a stray `*)` is code, an unterminated comment runs to the end (Rocq rejects the
        file), and an unterminated string stays as it is."""
        self.assertEqual(rocq.code("a (*) b *) c"), "a c")
        self.assertEqual(rocq.code("a *) b"), "a *) b")
        self.assertEqual(rocq.code("a (* b"), "a")
        self.assertEqual(rocq.code('a "b c'), 'a "b c')

    def test_a_crlf_distribution_header_splits_like_an_lf_one(self):
        self.assertEqual(facts.split_distribution("(** h *)\r\nDefinition a := 0.\r\n")[1], "Definition a := 0.\r\n")
        self.assertEqual(facts.split_distribution("(** h *)\nDefinition a := 0.\n")[1], "Definition a := 0.\n")


class Fingerprints(unittest.TestCase):
    """A statement's fingerprint hashes the code of theories/Shapes.v and theories/Images.v, not their bytes."""
    SHAPES = ('(** * The shapes\n\n    Prose (* nested *) about them. *)\nDefinition tag : string := "(* not a comment".\n'
              "Definition halts (x : nat) : Prop :=\n  x = 0.\n")

    def edited(self, rel, edit):
        """Every statement's fingerprint, before and after rel goes from SHAPES to edit(SHAPES)."""
        with tree() as t:
            t.write(rel, self.SHAPES)
            before = {s.id: s.fingerprint for s in facts.load(t.root).statements() if s.fingerprint}
            t.write(rel, edit(self.SHAPES))
            after = {s.id: s.fingerprint for s in facts.load(t.root).statements() if s.fingerprint}
        self.assertTrue(before)
        self.assertEqual(sorted(before), sorted(after))
        return before, after

    def test_a_comment_edit_changes_none(self):
        for rel in ("theories/Shapes.v", "theories/Images.v"):
            before, after = self.edited(rel, lambda s: s.replace("about them", "about (* the *) shapes") + "(* end *)\n")
            self.assertEqual(before, after, rel)

    def test_a_layout_edit_changes_none(self):
        before, after = self.edited("theories/Shapes.v", lambda s: s.replace(":=\n  x = 0.", ":=   x\t= 0.\n\n"))
        self.assertEqual(before, after)

    def test_a_comment_bracket_in_a_string_opens_no_comment(self):
        before, after = self.edited("theories/Shapes.v", lambda s: s.replace("x = 0", "x = 1"))
        self.assertTrue(all(before[k] != after[k] for k in before))

    def test_a_string_literal_is_code(self):
        before, after = self.edited("theories/Shapes.v", lambda s: s.replace("not a comment", "not  a comment"))
        self.assertTrue(all(before[k] != after[k] for k in before))

    def test_a_carriage_return_in_a_distribution_string_is_hashed(self):
        bound, dist = "zlib/checksum_fuzzer/asan_disagrees_at_most", "projects/zlib/checksum_fuzzer/Distribution.v"
        with tree() as t:
            text = t.read(dist)
            seen = set()
            for literal in ('"a\nb"', '"a\r\nb"'):
                t.write(dist, text + "Definition s := %s.\n" % literal)
                seen.add(next(s.fingerprint for s in facts.load(t.root).statements() if s.id == bound))
        self.assertEqual(len(seen), 2)

    def test_a_carriage_return_in_a_distribution_string_survives_generate_then_check(self):
        dist = "projects/zlib/checksum_fuzzer/Distribution.v"
        with tree() as t:
            t.write(dist, t.read(dist) + 'Definition s := "a\rb".\n')
            self.assertEqual(t.generate(), 0, t.last_output)
            self.assertEqual(t.generate(check=True), 0, t.last_output)


class Schemas(unittest.TestCase):
    def test_the_fixture_validates(self):
        with tree(render=False) as t:
            for rel, kind in (("release.yaml", "release"), ("projects/zlib/project.yaml", "project"),
                              ("projects/zlib/checksum_fuzzer/harness.yaml", "harness")):
                self.assertEqual(schema.validate(kind, t.yaml(rel)), [], rel)

    def test_closed(self):
        with tree(render=False) as t:
            y = t.yaml("projects/zlib/project.yaml")
            y["colour"] = {"shade": "blue"}
            self.assertTrue(any("unknown key" in e for e in schema.validate("project", y)))

    def test_yaml_is_strict(self):
        self.assertEqual(yamlio.load("d: 2026-11-02\nb: yes\n"), {"d": "2026-11-02", "b": "yes"})
        with self.assertRaises(yamlio.YamlError):
            yamlio.load("a: 1\na: 2\n")

    def test_every_template_placeholder_has_a_value(self):
        """A missing value raises; rendering the fixture exercises every block used."""
        with tree() as t:
            self.assertTrue(os.path.isfile(t.path("projects/zlib/checksum_fuzzer/Characterise.v")))



class UninstrumentedWords(unittest.TestCase):
    def test_the_readme_names_what_each_build_links_uninstrumented(self):
        with tree() as t:
            h = "projects/zlib/checksum_fuzzer/harness.yaml"
            y = t.yaml(h)
            y["builds"]["asan"]["uninstrumented"] = [
                {"name": "libclang_rt.asan.a", "kind": "sanitizer-runtime"},
                {"name": "crc32_x86.S.o", "kind": "assembly", "source": "contrib/crc32_x86.S"}]
            t.put_yaml(h, y)
            self.assertEqual(t.generate(), 0)
            readme = t.read("projects/zlib/checksum_fuzzer/README.md")
            self.assertIn("- asan: `libclang_rt.asan.a` (the sanitizer runtime), `crc32_x86.S.o` from "
                          "`contrib/crc32_x86.S` (assembly)", readme)
            self.assertNotIn("is not recorded in this release", readme)

    def test_with_no_list_the_readme_says_it_is_not_recorded(self):
        with tree() as t:
            readme = t.read("projects/zlib/checksum_fuzzer/README.md")
            self.assertIn("Which other code each build links uninstrumented is not recorded in this release.", readme)
            st = t.read("projects/zlib/checksum_fuzzer/Statements.v")
            self.assertIn("in the code it instruments", st)


class PublishedModel(unittest.TestCase):
    def test_publishing_the_model_changes_the_readme_and_no_fingerprint(self):
        """semantics.published: the model is public at its commit while its version is still unreleased."""
        with tree() as t:
            r = t.yaml("release.yaml")
            r["semantics"]["version"] = "unreleased"
            t.put_yaml("release.yaml", r)
            for p in ("proofs", "counterexamples"):         # fingerprints move with the version: no evidence here
                shutil.rmtree(t.path(p), ignore_errors=True)
            self.assertEqual(t.generate(), 0, t.last_output)
            self.assertIn("Nothing here can be checked from outside yet", t.read("README.md"))
            before = t.read("index/statements.tsv")
            r["semantics"]["published"] = True
            t.put_yaml("release.yaml", r)
            self.assertEqual(t.generate(), 0, t.last_output)
            readme = t.read("README.md")
            self.assertNotIn("Nothing here can be checked from outside yet", readme)
            c = r["semantics"]["commit"]
            self.assertIn("commit [`%s`](%s/commit/%s)" % (c[:12], r["semantics"]["repository"], c), readme)
            self.assertEqual(t.read("index/statements.tsv"), before)


if __name__ == "__main__":
    unittest.main()


class HeldAndExitWitness(unittest.TestCase):
    """A project or a fuzz target held from the release says only that, with no reason; a witness may end in an
    exit with a status the halts statement does not allow."""

    def test_a_held_project_page_says_only_that_it_is_held(self):
        with tree() as t:
            y = t.yaml("projects/imagemagick/project.yaml")
            y.update(status="held", reason="held")
            y.pop("reason_args")
            t.put_yaml("projects/imagemagick/project.yaml", y)
            self.assertEqual(t.generate(), 0, t.last_output)
            self.assertEqual([str(f) for f in t.lint()], [])
            page = t.read("projects/imagemagick/README.md")
            status = t.read("index/STATUS.md")
        self.assertIn("**Status: held.** Held from this release. [What the statuses mean]", page)
        self.assertNotIn("Ghostscript", page)
        self.assertIn("| [imagemagick](../projects/imagemagick/) | c++ | held |", status)

    def test_a_held_project_takes_no_reason_text(self):
        with tree() as t:
            y = t.yaml("projects/imagemagick/project.yaml")
            y.update(status="held", reason="dependency")
            t.put_yaml("projects/imagemagick/project.yaml", y)
            t.generate()
            self.assertTrue(any("is not a held reason" in f.msg for f in t.lint()))

    def test_a_held_fuzz_target_is_listed_as_held(self):
        with tree() as t:
            y = t.yaml("projects/zlib/project.yaml")
            for e in y["harnesses"]:
                if e["name"] == "minigzip_fuzzer":
                    e["reason"] = "held"
            t.put_yaml("projects/zlib/project.yaml", y)
            self.assertEqual(t.generate(), 0, t.last_output)
            self.assertEqual([str(f) for f in t.lint()], [])
            page = t.read("projects/zlib/README.md")
        self.assertIn("**minigzip_fuzzer** (held from this release)", page)

    def hold_zlib_api_driver(self, t, origin=True):
        """zlib's API driver held: listed as not included with reason held, its directory moved out of the tree (not
        deleted), and release.yaml's counts without its harness and builds."""
        y = t.yaml("projects/zlib/project.yaml")
        for e in y["harnesses"]:
            if e["name"] == "api-driver":
                e.update(status="not-included", reason="held")
                if not origin:
                    e.pop("origin")
        y.pop("withheld")           # the fixture's only withheld statement is the API driver's
        t.put_yaml("projects/zlib/project.yaml", y)
        n_builds = len(t.yaml("projects/zlib/api-driver/harness.yaml")["builds"])
        os.rename(t.path("projects/zlib/api-driver"), t.path("..", "api-driver-aside"))
        r = t.yaml("release.yaml")
        r["counts"]["harnesses"] -= 1
        r["counts"]["binaries"] -= n_builds
        t.put_yaml("release.yaml", r)

    def test_a_held_api_driver_is_listed_as_held_and_counted_nowhere(self):
        with tree() as t:
            self.hold_zlib_api_driver(t)
            self.assertEqual(t.generate(), 0, t.last_output)
            self.assertEqual([str(f) for f in t.lint()], [])
            page = t.read("projects/zlib/README.md")
            status = t.read("index/STATUS.md")
            row = [r for r in t.read("index/projects.tsv").splitlines() if r.startswith("zlib\t")]
        self.assertIn("**api-driver** (held from this release)", page)
        self.assertNotIn("plus an API driver", page)
        self.assertIn("| [zlib](../projects/zlib/) | c++ | available | 1 of 2 |", status)
        self.assertEqual(row[0].split("\t")[6], "no")
        # control: the included API driver is counted in both
        with tree() as t:
            self.assertIn("| [zlib](../projects/zlib/) | c++ | available | 1 of 2 + API driver |",
                          t.read("index/STATUS.md"))
            row = [r for r in t.read("index/projects.tsv").splitlines() if r.startswith("zlib\t")]
            self.assertEqual(row[0].split("\t")[6], "yes")

    def test_a_held_api_driver_still_has_origin_this_repository(self):
        with tree() as t:
            self.hold_zlib_api_driver(t, origin=False)
            t.generate()
            self.assertTrue(any("api-driver, and only api-driver, has origin this-repository" in f.msg
                                for f in t.lint()))

    def exit_witness(self, t, **w):
        y = t.yaml("projects/zlib/checksum_fuzzer/harness.yaml")
        wit = {"build": "plain", "input_hex": "01000000000000", "outcome": "exit", "exit": 78,
               "runner": "qemu-riscv64 10.0.11"}
        wit.update(w)
        y["statements"]["plain_halts"].update(status="witnessed-false", witness={k: v for k, v in wit.items()
                                                                                if v is not None})
        y["statements"]["plain_halts"].pop("binds_checks", None)
        t.put_yaml("projects/zlib/checksum_fuzzer/harness.yaml", y)

    def test_a_witness_that_ends_in_an_exit(self):
        with tree() as t:
            self.exit_witness(t)
            self.assertEqual(t.generate(), 0, t.last_output)
            self.assertEqual([str(f) for f in t.lint()], [])
            r = t.read("projects/zlib/checksum_fuzzer/README.md")
        self.assertIn("false (witnessed): with the input file `01 00 00 00 00 00 00` and nothing refused, the plain "
                      "build ends in exit status 78 (run under qemu-riscv64 10.0.11)", r)

    def test_an_exit_witness_must_be_one_the_statement_forbids(self):
        for w, msg in (({"exit": 2}, "which the statement allows"),
                       ({"exit": None}, "exactly when it ends in an exit"),
                       ({"after": "failed-assertion"}, "`after` is for a witness that ends in a signal")):
            with tree() as t:
                self.exit_witness(t, **w)
                t.generate()
                self.assertTrue(any(msg in f.msg for f in t.lint()), (w, [str(f) for f in t.lint()]))
        with tree() as t:
            # an abort with an exit status is refused too: the status is the exit's
            self.exit_witness(t, outcome="abort")
            t.generate()
            self.assertTrue(any("exactly when it ends in an exit" in f.msg for f in t.lint()))


class ProofLibrary(unittest.TestCase):
    def test_a_harness_library_gets_a_dune_and_its_proofs_depend_on_it(self):
        with tree() as t:
            st = next(s for s in facts.load(t.root).statements() if s.id == "zlib/checksum_fuzzer/plain_halts")
            t.put_yaml("proofs/zlib/checksum_fuzzer/plain_halts/proof.yaml", {
                "schema": "oss-fuzz-theorems/proof/1", "proves": st.id, "fingerprint": st.fingerprint})
            t.write("proofs/zlib/checksum_fuzzer/plain_halts/Proof.v", "Theorem plain_halts_holds : True. Proof. exact I. Qed.\n")
            self.assertEqual(t.generate(), 0, t.last_output)
            self.assertNotIn("OssFuzzTheorems.Proofs.zlib.checksum_fuzzer.lib",
                             t.read("proofs/zlib/checksum_fuzzer/plain_halts/dune"))
            t.write("proofs/zlib/checksum_fuzzer/lib/Sub/Deep.v", "Definition two := 2.\n")
            self.assertEqual(t.generate(), 0, t.last_output)
            lib = t.read("proofs/zlib/checksum_fuzzer/lib/dune")
            self.assertIn("(include_subdirs qualified)", lib)
            self.assertIn("(name OssFuzzTheorems.Proofs.zlib.checksum_fuzzer.lib)", lib)
            self.assertIn("(package rocq-oss-fuzz-theorems-zlib-proofs)", lib)
            self.assertIn(" OssFuzzTheorems.zlib.checksum_fuzzer OssFuzzTheorems.Proofs.zlib.checksum_fuzzer.lib)",
                          t.read("proofs/zlib/checksum_fuzzer/plain_halts/dune"))
            self.assertEqual(t.generate(check=True), 0, t.last_output)
