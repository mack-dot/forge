(* Auxiliary obligation only; original termination theorem unchanged. *)
From Stdlib Require Import ZArith List.
From LinuxProcessSemantics.LinuxProcessSem Require Import BvBase RiscvSemantics State Run.
From LinuxProcessSemantics.LinuxProcessSem.Checks Require Import Omni.
Require ForgeObserved.ObservedTransitions.
From Forge.Binary.images Require Program.
Import ListNotations.
Module O := ForgeObserved.ObservedTransitions.
Module G := Program.M.

Lemma empty_access_list_preserves_existing_model : forall model,
 materialize_model_accesses model [] = Some model.
Proof. intros [fd [maps lazy materialized] io fs proc lim tm]. reflexivity. Qed.
