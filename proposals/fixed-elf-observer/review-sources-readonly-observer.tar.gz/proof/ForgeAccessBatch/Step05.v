(* Local auxiliary obligation. Original termination theorem unchanged. *)
From Stdlib Require Import ZArith List Lia.
From LinuxProcessSemantics.LinuxProcessSem Require Import BvBase RiscvSemantics State Run.
From LinuxProcessSemantics.LinuxProcessSem.Checks Require Import Omni.
Require ForgeObserved.ObservedTransitions.
From Forge.Binary.images Require Program.
Import ListNotations.
Module O := ForgeObserved.ObservedTransitions.
Module G := Program.M.

Lemma step_5_has_no_data_accesses : forall rnd argv envp uid hw mem resv fcsr,
(match run_steps 5 G.loaded_segments
 (O.observed_initial_machine rnd argv envp uid hw mem resv fcsr) with
 | Some st => match RiscvSemantics.step_accesses G.loaded_segments st with
   | MachineOk report => Some (@accessed_ranges _ report)
   | _ => None end
 | None => None end) = Some [] .
Proof. intros. vm_compute. reflexivity. Qed.
