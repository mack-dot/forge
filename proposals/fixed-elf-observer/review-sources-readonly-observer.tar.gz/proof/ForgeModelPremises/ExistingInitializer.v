(* Local obligation check only. Existing theorem remains unchanged. *)
From Stdlib Require Import ZArith List.
From LinuxProcessSemantics.LinuxProcessSem Require Import BvBase State Run.
From LinuxProcessSemantics.LinuxProcessSem.Checks Require Import Omni.
From LinuxProcessSemantics.EquivalenceDefinition Require Import MustExit Classifier.
Require ForgeMemoryCandidate.MemoryIndependent.
From Forge.Binary.images Require Program.
Import ListNotations.
Module C := ForgeMemoryCandidate.MemoryIndependent.
Module G := Program.M.

Lemma existing_initializer_satisfies_model_premises :
 forall reserved brk0 mbase sp lim inp,
 m_halted (init_model reserved brk0 mbase sp lim inp) = None /\
 m_vm_lazy (init_model reserved brk0 mbase sp lim inp) = [].
Proof. intros. split; reflexivity. Qed.

Lemma existing_theorem_applies_to_existing_initializer :
 forall sp rnd argv envp uid hw mem reserved brk0 mbase lim inp,
 must_exit_at_cfg may_fail_cfg G.loaded_segments verdict_accept
  (mkCfg (with_mem
    (init_machine_state G.loaded_segments G.init_pc G.phdrs sp rnd argv envp uid hw) mem)
    (init_model reserved brk0 mbase sp lim inp)).
Proof. intros. apply C.selftest_memory_independent_termination_holds; reflexivity. Qed.
