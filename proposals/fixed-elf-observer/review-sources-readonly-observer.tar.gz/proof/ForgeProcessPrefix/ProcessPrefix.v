(* Auxiliary process-prefix composition over published LPS relations only.
   This neither changes the termination theorem nor relates physical QEMU state. *)
From Stdlib Require Import ZArith List Lia.
From LinuxProcessSemantics.LinuxProcessSem Require Import BvBase RiscvSemantics State Run.
From LinuxProcessSemantics.LinuxProcessSem.Checks Require Import Omni.
Require ForgeObserved.ObservedTransitions.
Require ForgeAccessCombined.AllAccesses.
Require ForgePendingBoundary.PendingBoundary.
From Forge.Binary.images Require Program.
Import ListNotations.
Module O := ForgeObserved.ObservedTransitions.
Module A := ForgeAccessCombined.AllAccesses.
Module P := ForgePendingBoundary.PendingBoundary.
Module G := Program.M.

Lemma run_steps_successor_at_reached_state : forall segs n start middle,
 run_steps n segs start = Some middle ->
 run_steps (S n) segs start =
 (match RiscvSemantics.step segs middle with
  | MachineOk next => Some next
  | MachineFault | MachineUnmodeled => None end).
Proof.
 intros segs n. induction n as [|n IH]; intros start middle Hrun.
 - cbn [run_steps] in Hrun. injection Hrun as Heq. subst middle.
   cbn [run_steps]. destruct (RiscvSemantics.step segs start); reflexivity.
 - cbn [run_steps] in Hrun |- *.
   destruct (RiscvSemantics.step segs start) as [next| |] eqn:Hstep;
     try discriminate Hrun.
   apply IH. exact Hrun.
Qed.

Lemma every_recorded_instruction_is_a_process_step :
 forall rnd argv envp uid hw mem resv fcsr model cfg k,
 m_halted model = None -> (k < 21)%nat ->
 exists current next,
 run_steps k G.loaded_segments
  (O.observed_initial_machine rnd argv envp uid hw mem resv fcsr) = Some current /\
 run_steps (S k) G.loaded_segments
  (O.observed_initial_machine rnd argv envp uid hw mem resv fcsr) = Some next /\
 sstep_cfg G.loaded_segments cfg (mkCfg current model) []
  (SNext (mkCfg next model)).
Proof.
 intros rnd argv envp uid hw mem resv fcsr model cfg k Hhalt Hk.
 pose proof (A.all_observed_accounting_preserves_model
  rnd argv envp uid hw mem resv fcsr model k Hk) as Haccount.
 pose proof (P.no_pending_syscall_before_recorded_instructions
  rnd argv envp uid hw mem resv fcsr k Hk) as Hpending.
 destruct (run_steps k G.loaded_segments
  (O.observed_initial_machine rnd argv envp uid hw mem resv fcsr))
  as [current|] eqn:Hrun; [|discriminate Haccount].
 cbn in Hpending. injection Hpending as Hpending.
 destruct (mi_account_step G.loaded_segments current model)
  as [[next model2]| |] eqn:Haccount_step;
  try discriminate Haccount.
 cbn in Haccount. injection Haccount as Hmodel. subst model2.
 exists current, next. split; [reflexivity|]. split.
 - rewrite (run_steps_successor_at_reached_state _ _ _ _ Hrun).
   rewrite (mi_account_step_projects _ _ _ _ _ Haccount_step). reflexivity.
 - eapply sstep_cfg_instr; eassumption.
Qed.

Lemma existing_star_cfg_append : forall segs cfg c0 tr1 c1 tr2 c2,
 star_cfg segs cfg c0 tr1 c1 ->
 star_cfg segs cfg c1 tr2 c2 ->
 star_cfg segs cfg c0 (tr1 ++ tr2) c2.
Proof.
 intros segs cfg c0 tr1 c1 tr2 c2 Hstar.
 induction Hstar; intros Hend.
 - cbn. exact Hend.
 - rewrite <- app_assoc. eapply star_cfg_step.
   + exact H.
   + apply IHHstar. exact Hend.
Qed.

Lemma recorded_prefix_is_a_process_trace :
 forall rnd argv envp uid hw mem resv fcsr model cfg,
 m_halted model = None -> forall n, (n <= 21)%nat ->
 exists last,
 run_steps n G.loaded_segments
  (O.observed_initial_machine rnd argv envp uid hw mem resv fcsr) = Some last /\
 star_cfg G.loaded_segments cfg
  (mkCfg (O.observed_initial_machine rnd argv envp uid hw mem resv fcsr) model)
  [] (mkCfg last model).
Proof.
 intros rnd argv envp uid hw mem resv fcsr model cfg Hhalt n.
 induction n as [|n IH]; intro Hn.
 - exists (O.observed_initial_machine rnd argv envp uid hw mem resv fcsr).
   split; [reflexivity|apply star_cfg_refl].
 - destruct (IH ltac:(lia)) as [middle [Hmiddle Hstar]].
   destruct (every_recorded_instruction_is_a_process_step
    rnd argv envp uid hw mem resv fcsr model cfg n Hhalt ltac:(lia))
    as [current [next [Hcurrent [Hnext Hstep]]]].
   rewrite Hmiddle in Hcurrent. injection Hcurrent as Heq. subst current.
   exists next. split; [exact Hnext|].
   eapply existing_star_cfg_append with (tr1 := []) (tr2 := []).
   + exact Hstar.
   + eapply star_cfg_step with (evs := []) (tr := []);
       [exact Hstep|apply star_cfg_refl].
Qed.

Corollary recorded_process_prefix_reaches_pending_exit :
 forall rnd argv envp uid hw mem resv fcsr model cfg,
 m_halted model = None ->
 exists last,
 run_steps 21 G.loaded_segments
  (O.observed_initial_machine rnd argv envp uid hw mem resv fcsr) = Some last /\
 star_cfg G.loaded_segments cfg
  (mkCfg (O.observed_initial_machine rnd argv envp uid hw mem resv fcsr) model)
  [] (mkCfg last model) /\
 ms_svc_pending last = Some (Z_to_bv 64 94) /\
 ms_reg last (Z_to_bv 5 10) = Z_to_bv 64 0.
Proof.
 intros rnd argv envp uid hw mem resv fcsr model cfg Hhalt.
 destruct (recorded_prefix_is_a_process_trace
  rnd argv envp uid hw mem resv fcsr model cfg Hhalt 21 ltac:(lia))
  as [last [Hrun Hstar]].
 pose proof (O.modeled_exit_syscall_request rnd argv envp uid hw mem resv fcsr)
  as Hexit. rewrite Hrun in Hexit. cbn in Hexit.
 exists last. split; [exact Hrun|]. split; [exact Hstar|].
 injection Hexit as Hpending Hcode. split; assumption.
Qed.
