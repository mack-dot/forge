(* Local auxiliary obligation. Original termination theorem unchanged. *)
From Stdlib Require Import ZArith List Lia.
From LinuxProcessSemantics.LinuxProcessSem Require Import BvBase RiscvSemantics State Run.
From LinuxProcessSemantics.LinuxProcessSem.Checks Require Import Omni.
Require ForgeObserved.ObservedTransitions.
From Forge.Binary.images Require Program.
Import ListNotations.
Module O := ForgeObserved.ObservedTransitions.
Module G := Program.M.
Require ForgeOneStepAccess.Access.
Require ForgeAccessDecomposition.EmptyAccounting ForgeAccessDecomposition.LastAccess.
Require ForgeAccessBatch.Step01.
Require ForgeAccessBatch.Step02.
Require ForgeAccessBatch.Step03.
Require ForgeAccessBatch.Step04.
Require ForgeAccessBatch.Step05.
Require ForgeAccessBatch.Step06.
Require ForgeAccessBatch.Step07.
Require ForgeAccessBatch.Step08.
Require ForgeAccessBatch.Step09.
Require ForgeAccessBatch.Step10.
Require ForgeAccessBatch.Step11.
Require ForgeAccessBatch.Step12.
Require ForgeAccessBatch.Step13.
Require ForgeAccessBatch.Step14.
Require ForgeAccessBatch.Step15.
Require ForgeAccessBatch.Step16.
Require ForgeAccessBatch.Step17.
Require ForgeAccessBatch.Step18.
Require ForgeAccessBatch.Step19.

Lemma all_observed_instruction_accesses_empty : forall rnd argv envp uid hw mem resv fcsr k,
 (k < 21)%nat ->
(match run_steps k G.loaded_segments
 (O.observed_initial_machine rnd argv envp uid hw mem resv fcsr) with
 | Some st => match RiscvSemantics.step_accesses G.loaded_segments st with
   | MachineOk report => Some (@accessed_ranges _ report)
   | _ => None end
 | None => None end) = Some [].
Proof.
 intros rnd argv envp uid hw mem resv fcsr k Hk.
 destruct k as [|k]; [apply ForgeOneStepAccess.Access.first_instruction_has_no_data_accesses |].
 destruct k as [|k]; [apply ForgeAccessBatch.Step01.step_1_has_no_data_accesses |].
 destruct k as [|k]; [apply ForgeAccessBatch.Step02.step_2_has_no_data_accesses |].
 destruct k as [|k]; [apply ForgeAccessBatch.Step03.step_3_has_no_data_accesses |].
 destruct k as [|k]; [apply ForgeAccessBatch.Step04.step_4_has_no_data_accesses |].
 destruct k as [|k]; [apply ForgeAccessBatch.Step05.step_5_has_no_data_accesses |].
 destruct k as [|k]; [apply ForgeAccessBatch.Step06.step_6_has_no_data_accesses |].
 destruct k as [|k]; [apply ForgeAccessBatch.Step07.step_7_has_no_data_accesses |].
 destruct k as [|k]; [apply ForgeAccessBatch.Step08.step_8_has_no_data_accesses |].
 destruct k as [|k]; [apply ForgeAccessBatch.Step09.step_9_has_no_data_accesses |].
 destruct k as [|k]; [apply ForgeAccessBatch.Step10.step_10_has_no_data_accesses |].
 destruct k as [|k]; [apply ForgeAccessBatch.Step11.step_11_has_no_data_accesses |].
 destruct k as [|k]; [apply ForgeAccessBatch.Step12.step_12_has_no_data_accesses |].
 destruct k as [|k]; [apply ForgeAccessBatch.Step13.step_13_has_no_data_accesses |].
 destruct k as [|k]; [apply ForgeAccessBatch.Step14.step_14_has_no_data_accesses |].
 destruct k as [|k]; [apply ForgeAccessBatch.Step15.step_15_has_no_data_accesses |].
 destruct k as [|k]; [apply ForgeAccessBatch.Step16.step_16_has_no_data_accesses |].
 destruct k as [|k]; [apply ForgeAccessBatch.Step17.step_17_has_no_data_accesses |].
 destruct k as [|k]; [apply ForgeAccessBatch.Step18.step_18_has_no_data_accesses |].
 destruct k as [|k]; [apply ForgeAccessBatch.Step19.step_19_has_no_data_accesses |].
 destruct k as [|k]; [apply ForgeAccessDecomposition.LastAccess.last_observed_instruction_has_no_data_accesses |].
 exfalso. lia.
Qed.

Lemma all_observed_accounting_preserves_model : forall rnd argv envp uid hw mem resv fcsr model k,
 (k < 21)%nat ->
 (match run_steps k G.loaded_segments
  (O.observed_initial_machine rnd argv envp uid hw mem resv fcsr) with
 | Some st => match mi_account_step G.loaded_segments st model with
   | MachineOk (_, model2) => Some model2
   | _ => None end
 | None => None end) = Some model.
Proof.
 intros rnd argv envp uid hw mem resv fcsr model k Hk.
 pose proof (all_observed_instruction_accesses_empty rnd argv envp uid hw mem resv fcsr k Hk) as H.
 destruct (run_steps k G.loaded_segments
  (O.observed_initial_machine rnd argv envp uid hw mem resv fcsr)) as [st|] eqn:E.
 - change (match RiscvSemantics.step_accesses G.loaded_segments st with
   | MachineOk report => Some (@accessed_ranges _ report)
   | _ => None end = Some []) in H.
   change (match mi_account_step G.loaded_segments st model with
   | MachineOk (_, model2) => Some model2
   | _ => None end = Some model).
   unfold mi_account_step.
   destruct (RiscvSemantics.step_accesses G.loaded_segments st) as [report| |] eqn:Er.
   + injection H as Hrange.
     rewrite Hrange, ForgeAccessDecomposition.EmptyAccounting.empty_access_list_preserves_existing_model.
     reflexivity.
   + discriminate H.
   + discriminate H.
 - discriminate H.
Qed.
