(* Auxiliary local obligation only. No accepted theorem/policy change. *)
From Stdlib Require Import ZArith List.
From LinuxProcessSemantics.LinuxProcessSem Require Import BvBase RiscvSemantics State Run.
Require ForgeObserved.ObservedTransitions.
From Forge.Binary.images Require Program.
Import ListNotations.
Module O := ForgeObserved.ObservedTransitions.
Module G := Program.M.
Lemma first_instruction_has_no_data_accesses : forall rnd argv envp uid hw mem resv fcsr,
 (match RiscvSemantics.step_accesses G.loaded_segments
   (O.observed_initial_machine rnd argv envp uid hw mem resv fcsr) with
 | MachineOk report => Some (@accessed_ranges _ report)
 | _ => None end) = Some [].
Proof. intros. vm_compute. reflexivity. Qed.
