(* Auxiliary process-boundary check. Original theorem is unchanged. *)
From Stdlib Require Import ZArith List Lia.
From LinuxProcessSemantics.LinuxProcessSem Require Import BvBase RiscvSemantics State Run.
From LinuxProcessSemantics.LinuxProcessSem.Checks Require Import Omni.
Require ForgeObserved.ObservedTransitions.
From Forge.Binary.images Require Program.
Import ListNotations.
Module O := ForgeObserved.ObservedTransitions.
Module G := Program.M.

Lemma no_pending_syscall_before_recorded_instructions : forall rnd argv envp uid hw mem resv fcsr k,
 (k < 21)%nat ->
 option_map ms_svc_pending (run_steps k G.loaded_segments
  (O.observed_initial_machine rnd argv envp uid hw mem resv fcsr)) = Some None.
Proof.
 intros rnd argv envp uid hw mem resv fcsr k Hk.
 do 21 (destruct k as [|k]; [vm_compute; reflexivity |]).
 exfalso. lia.
Qed.
Lemma pending_exit_after_recorded_instructions : forall rnd argv envp uid hw mem resv fcsr,
 option_map ms_svc_pending (run_steps 21 G.loaded_segments
  (O.observed_initial_machine rnd argv envp uid hw mem resv fcsr)) = Some (Some (Z_to_bv 64 94)).
Proof. intros. vm_compute. reflexivity. Qed.
