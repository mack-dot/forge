set pagination off
set confirm off
set auto-load off
set debuginfod enabled off
set tcp auto-retry on
file /tmp/gcd-selftest.elf
target remote 127.0.0.1:12345
printf "FORGE_ENTRY_PC=%#lx\n", $pc
printf "FORGE_ENTRY_SP=%#lx\n", $sp
printf "FORGE_ENTRY_FCSR=%#lx\n", $fcsr
info all-registers
dump binary memory /records/live-load-ro.bin 0x10000 0x10158
dump binary memory /records/live-load-text.bin 0x11158 0x11194
python
import gdb, json, re
auxv = gdb.execute("info auxv", to_string=True)
gdb.write(auxv)
rows = [line for line in auxv.splitlines() if "AT_SYSINFO_EHDR" in line]
if len(rows) != 1:
    raise RuntimeError("Guest auxiliary vector did not expose a unique VDSO address")
match = re.search(r"0x([0-9a-fA-F]+)\s*$", rows[0])
if not match:
    raise RuntimeError("Guest VDSO address is not available as debugger text")
address = int(match.group(1), 16)
gdb.execute("dump binary memory /records/live-vdso-page.bin %#x %#x" % (address, address + 4096))
with open("/records/auxiliary-vector.txt", "w") as f:
    f.write(auxv)
with open("/records/vdso-address.json", "w") as f:
    json.dump({"guest_vdso_address": address, "bytes_captured": 4096,
               "source": "Existing GDB info auxv / QEMU qXfer:auxv; observation only"}, f, indent=2)
    f.write("\n")
end
continue
printf "FORGE_GUEST_EXIT=%d\n", $_exitcode
if $_exitcode != 0
  quit 1
end
quit 0
