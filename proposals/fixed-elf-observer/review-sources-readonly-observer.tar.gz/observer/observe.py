"""Observe one new fixed-ELF run using standard pinned QEMU/GDB/binutils.

Expected ELF/runtime bytes come from held historical identities, not the
debugger or a candidate. This is finite observation, never a proof/admission.
"""
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time

sys.path.insert(0, '/observer-code')
from marker_fields import exact_fields

OUT = Path('/records')
QEMU = Path('/runtime/qemu-riscv64-static')
ELF = Path('/target/gcd-selftest.elf')
GDB = Path('/observer/usr/bin/gdb-multiarch')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')

assert sha(QEMU) == 'be89e201dc6112ef101617ab575c95119ad123f80ca2b51b6c36ef218ac9df65'
assert sha(ELF) == '8ced2ab6c7160338899056fe51bacb23d86d81705eacfdd1e992cf5252bdaeb6'
assert sha(GDB) == '0baeb299d3aa39f40ca72c3cb8ae5b15a5bd01f1995583a52cfdd7527bfffe07'
assert sha(Path('/usr/bin/readelf')) == '64c58e15274bbbb5153f31078e455e9e77ee5f51489e709bba5bb788ce9df2b0'
target = Path('/tmp/gcd-selftest.elf')
shutil.copyfile(ELF, target)
target.chmod(0o555)
commands = []

def run(argv, label, env=None):
    proc = subprocess.run(argv, env=env, capture_output=True)
    (OUT / (label + '.stdout')).write_bytes(proc.stdout)
    (OUT / (label + '.stderr')).write_bytes(proc.stderr)
    commands.append({'argv': argv, 'actual_exit': proc.returncode})
    save('commands.json', commands)
    return proc

headers = run(['readelf', '--program-headers', '--wide', str(ELF)], 'held-elf-headers')
assert headers.returncode == 0
for label, skip, count in [('ro', 0, 344), ('text', 344, 60)]:
    proc = run(['dd', 'if=' + str(ELF), 'of=' + str(OUT / ('expected-' + label + '.bin')),
                'bs=1', 'skip=' + str(skip), 'count=' + str(count)], 'held-' + label)
    assert proc.returncode == 0
qemu_cmd = [str(QEMU), '-cpu', 'rv64', '-s', '8388608', '-g', '12345',
            '-one-insn-per-tb', '-strace', '-d', 'in_asm,cpu,fpu,page,nochain',
            '-D', str(OUT / 'instruction-trace.log'), str(target)]
gdb_cmd = [str(GDB), '--nx', '--nh', '--batch', '--data-directory=/observer/usr/share/gdb',
           '-iex', 'set auto-load off', '-iex', 'set debuginfod enabled off',
           '-x', '/commands.gdb']
env = dict(os.environ, LD_LIBRARY_PATH='/observer/usr/lib/x86_64-linux-gnu',
           PYTHONDONTWRITEBYTECODE='1')
save('execution-before.json', {'qemu_argv': qemu_cmd, 'gdb_argv': gdb_cmd,
    'gdb_library_path': env['LD_LIBRARY_PATH'],
    'gdb_dont_write_bytecode': env['PYTHONDONTWRITEBYTECODE'],
    'commands_sha256': sha(Path('/commands.gdb')),
    'elf_sha256': sha(ELF), 'qemu_sha256': sha(QEMU), 'gdb_sha256': sha(GDB),
    'scope': 'New debug-observed run;not the historical trace or authoritative proof evidence',
    'end_to_end': False})
start = time.monotonic()
with (OUT / 'qemu.stdout').open('wb') as stdout, (OUT / 'qemu.stderr').open('wb') as stderr:
    qemu = subprocess.Popen(qemu_cmd, stdout=stdout, stderr=stderr)
    save('live-process.json', {'qemu_pid': qemu.pid, 'expected_exit': 0})
    try:
        debug = run(gdb_cmd, 'debugger', env)
        assert debug.returncode == 0, 'DEBUGGER_OPERATION_FAILED'
        code = qemu.wait()
    finally:
        terminated_by_observer = False
        if qemu.poll() is None:
            terminated_by_observer = True
            qemu.terminate()
            qemu.wait()
        save('qemu-command.json', {'argv': qemu_cmd, 'actual_exit': qemu.returncode,
                                  'terminated_by_observer': terminated_by_observer})
assert code == 0
text = debug.stdout.decode()
markers = exact_fields(text)
matches = []
for label in ['ro', 'text']:
    expected = OUT / ('expected-' + label + '.bin')
    live = OUT / ('live-load-' + label + '.bin')
    cmp = run(['cmp', str(expected), str(live)], 'compare-' + label)
    assert cmp.returncode == 0, 'LIVE_LOAD_BYTES_DIFFER'
    matches.append({'part': label, 'bytes': live.stat().st_size, 'sha256': sha(live)})
corrupt = OUT / 'corrupt-live-text.bin'
data = bytearray((OUT / 'live-load-text.bin').read_bytes())
data[0] ^= 1
corrupt.write_bytes(data)
negative = run(['cmp', str(OUT / 'expected-text.bin'), str(corrupt)], 'compare-corrupt-text')
assert negative.returncode == 1, 'CORRUPT_CAPTURE_NOT_REJECTED'
vdso = run(['readelf', '--file-header', '--program-headers', '--wide',
            str(OUT / 'live-vdso-page.bin')], 'vdso-readelf')
assert vdso.returncode == 0, 'VDSO_CAPTURE_NOT_READABLE_AS_ELF'
assert sha(ELF) == sha(target) == '8ced2ab6c7160338899056fe51bacb23d86d81705eacfdd1e992cf5252bdaeb6'
result = {'scope': 'One new finite debug-observed execution;TESTED/OBSERVED only',
    'qemu_exit': code, 'gdb_exit': debug.returncode, 'held_load_bytes_matched': matches,
    'fcsr_observed_zero': markers['FORGE_ENTRY_FCSR'] == '0',
    'observed_markers': markers, 'corrupt_capture_comparison_exit': negative.returncode,
    'debugger_warnings': debug.stderr.decode(),
    'auxv_vdso_address': json.loads((OUT / 'vdso-address.json').read_text()),
    'reservation_observed': False, 'lps_sparse_ledger_observed': False,
    'old_run_hidden_state_established': False, 'runtime_refinement': 'NOT_ESTABLISHED',
    'authoritative_evidence_profile_approved': False, 'admitted': False,
    'wall_seconds': time.monotonic() - start, 'end_to_end': False}
save('result.json', result)
print(json.dumps(result), flush=True)
