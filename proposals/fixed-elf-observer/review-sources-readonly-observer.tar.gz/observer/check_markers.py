"""Adversarial metadata controls for this new observer only;not hosted receipt tests."""
import json
from pathlib import Path
import subprocess
import sys

out = Path('/records')
good = Path('/original/debugger.stdout').read_text()
cases = [
 ('actual-capture', good, 0, None),
 ('nonzero-fcsr', good.replace('FORGE_ENTRY_FCSR=0\n', 'FORGE_ENTRY_FCSR=0x1\n'), 1, 'FORGE_ENTRY_FCSR'),
 ('pc-suffix', good.replace('FORGE_ENTRY_PC=0x11158\n', 'FORGE_ENTRY_PC=0x111580\n'), 1, 'FORGE_ENTRY_PC'),
 ('missing-fcsr', good.replace('FORGE_ENTRY_FCSR=0\n', ''), 1, 'FORGE_ENTRY_FCSR'),
 ('duplicate-zero', good + '\nFORGE_ENTRY_FCSR=0\n', 1, 'FORGE_ENTRY_FCSR'),
 ('coordinated-zero-and-nonzero', good + '\nFORGE_ENTRY_FCSR=0x1\n', 1, 'FORGE_ENTRY_FCSR'),
 ('wrong-guest-exit', good.replace('FORGE_GUEST_EXIT=0\n', 'FORGE_GUEST_EXIT=1\n'), 1, 'FORGE_GUEST_EXIT'),
 ('zero-prefix-exit', good.replace('FORGE_GUEST_EXIT=0\n', 'FORGE_GUEST_EXIT=01\n'), 1, 'FORGE_GUEST_EXIT'),
 ('empty-output', '', 1, 'FORGE_ENTRY_PC'),
]
rows = []
for name, text, expected, reason in cases:
    path = out / (name + '.txt')
    path.write_text(text)
    argv = [sys.executable, '-I', '-S', '-B', '/code/marker_fields.py', str(path)]
    proc = subprocess.run(argv, capture_output=True, text=True)
    row = {'case': name, 'argv': argv, 'expected_exit': expected,
           'actual_exit': proc.returncode, 'stdout': proc.stdout, 'stderr': proc.stderr}
    rows.append(row)
    (out / 'results.json').write_text(json.dumps(rows, indent=2) + '\n')
    assert proc.returncode == expected
    if reason:
        assert 'OBSERVER_MARKER_MISMATCH:' + reason in proc.stderr
print(json.dumps({'cases': len(rows), 'local_observer_marker_controls_passed': True,
                  'hosted_receipt_security_matrix_changed': False, 'end_to_end': False}))
