"""Check exact emitted debugger metadata;not a proof or provenance verifier."""
import json
from pathlib import Path
import sys

def exact_fields(text):
    result = {}
    for name, expected in [('FORGE_ENTRY_PC', '0x11158'),
                           ('FORGE_ENTRY_FCSR', '0'), ('FORGE_GUEST_EXIT', '0')]:
        values = [line[len(name) + 1:] for line in text.splitlines()
                  if line.startswith(name + '=')]
        if values != [expected]:
            raise ValueError('OBSERVER_MARKER_MISMATCH:' + name)
        result[name] = values[0]
    return result

if __name__ == '__main__':
    try:
        print(json.dumps(exact_fields(Path(sys.argv[1]).read_text())))
    except ValueError as error:
        print(str(error), file=sys.stderr)
        raise SystemExit(1)
