"""Compare the read-only observer after execution with its authenticated inventory."""
import hashlib
import json
import os
from pathlib import Path
import stat

expected = json.loads(Path('/expected.json').read_text())
actual = {}
root = Path('/observer')
for path in sorted(root.rglob('*')):
    info = path.lstat()
    name = str(path.relative_to(root))
    if stat.S_ISLNK(info.st_mode):
        actual[name] = {'kind': 'symlink', 'target': os.readlink(path)}
    elif stat.S_ISREG(info.st_mode):
        actual[name] = {'kind': 'file', 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                        'mode': stat.S_IMODE(info.st_mode)}
    elif not stat.S_ISDIR(info.st_mode):
        raise AssertionError('UNSUPPORTED_OBSERVER_MEMBER:' + name)
assert actual == expected, 'OBSERVER_CHANGED_AFTER_AUTHENTICATION_OR_EXECUTION'
assert not any('__pycache__' in name for name in actual)
result = {'actual_post_execution_identity_exit': 0, 'members': len(actual),
          'matches_authenticated_before_execution_inventory': True,
          'new_bytecode_cache_members': 0, 'authoritative_profile_approved': False,
          'admitted': False, 'end_to_end': False}
Path('/records/producer-after.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
