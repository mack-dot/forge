"""Replay Ubuntu package authentication and compare a fresh unpacked observer.

gpgv authenticates publisher metadata. apt-helper and dpkg-deb interpret the
standard formats. Python binds existing-tool outputs by digest; it does not
judge program semantics, evidence provenance policy or formal correctness.
"""
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess

PACKAGES = Path('/packages')
OUT = Path('/records')
KEY = Path('/usr/share/keyrings/ubuntu-archive-keyring.gpg')
assert hashlib.sha256(KEY.read_bytes()).hexdigest() == '80a36b0a6de2f69f49d2df75ef473ccde121e9e190b9ea01d20a4f63778d5c31'
manifest = json.loads((PACKAGES / 'observer-packages.json').read_text())
assert manifest['version'] == '15.1-1ubuntu1~24.04.1'
wanted = {(v['package'], v['version']) for v in manifest['archives'].values()}
commands = []

def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

def run(argv, label, dest=None):
    if dest is None:
        proc = subprocess.run(argv, capture_output=True)
        (OUT / (label + '.stdout')).write_bytes(proc.stdout)
    else:
        with dest.open('wb') as f:
            proc = subprocess.run(argv, stdout=f, stderr=subprocess.PIPE)
    (OUT / (label + '.stderr')).write_bytes(proc.stderr)
    commands.append({'argv': argv, 'actual_exit': proc.returncode})
    save('commands.json', commands)
    assert proc.returncode == 0, label

authenticated = {}
indices = []
for suite in ['noble', 'noble-updates']:
    release = PACKAGES / 'apt-trust' / ('archive.ubuntu.com_ubuntu_dists_' + suite + '_InRelease')
    assert release.read_bytes() == (PACKAGES / 'apt-lists' / release.name).read_bytes()
    run(['gpgv', '--keyring', str(KEY), str(release)], suite + '-release')
    expected = {}
    inside = False
    for line in release.read_text().splitlines():
        if line == 'SHA256:':
            inside = True
            continue
        if inside and line.startswith(' '):
            digest, size, name = line.split()
            expected[name] = (digest, int(size))
        elif inside:
            break
    for component in ['main', 'universe']:
        name = component + '/binary-amd64/Packages'
        compressed = PACKAGES / 'apt-lists' / ('archive.ubuntu.com_ubuntu_dists_' + suite + '_' + component + '_binary-amd64_Packages.lz4')
        plain = OUT / (suite + '-' + component + '-Packages')
        run(['/usr/lib/apt/apt-helper', 'cat-file', str(compressed)], suite + '-' + component, plain)
        assert (sha(plain), plain.stat().st_size) == expected[name], 'SIGNED_BINARY_INDEX:' + name
        indices.append({'suite': suite, 'component': component, 'sha256': sha(plain)})
        paragraph = []
        def consume(lines):
            fields = {}
            for text in lines:
                if text and not text[0].isspace() and ': ' in text:
                    key, value = text.split(': ', 1)
                    fields[key] = value
            pair = (fields.get('Package'), fields.get('Version'))
            if pair in wanted:
                authenticated.setdefault(pair, set()).add(fields['SHA256'])
        with plain.open() as f:
            for line in f:
                if line.strip():
                    paragraph.append(line.rstrip('\n'))
                else:
                    consume(paragraph)
                    paragraph = []
            consume(paragraph)
assert set(authenticated) == wanted, 'ALL_OBSERVER_PACKAGES_IN_SIGNED_INDICES'
for i, (name, item) in enumerate(manifest['archives'].items()):
    path = PACKAGES / 'debs' / name
    digest = sha(path)
    assert digest == item['sha256'] and path.stat().st_size == item['bytes']
    assert digest in authenticated[(item['package'], item['version'])], name
    run(['dpkg-deb', '--extract', str(path), str(OUT / 'fresh-root')], 'extract-' + str(i))

def inventory(root):
    result = {}
    for path in sorted(root.rglob('*')):
        info = path.lstat()
        rel = str(path.relative_to(root))
        if stat.S_ISLNK(info.st_mode):
            result[rel] = {'kind': 'symlink', 'target': os.readlink(path)}
        elif stat.S_ISREG(info.st_mode):
            result[rel] = {'kind': 'file', 'sha256': sha(path), 'mode': stat.S_IMODE(info.st_mode)}
        elif not stat.S_ISDIR(info.st_mode):
            raise AssertionError('UNSUPPORTED_PACKAGE_MEMBER:' + rel)
    return result

fresh = inventory(OUT / 'fresh-root')
used = inventory(Path('/used-observer'))
save('fresh-observer-members.json', fresh)
save('used-observer-members.json', used)
assert fresh == used, 'USED_OBSERVER_DIFFERS_FROM_AUTHENTICATED_PACKAGE_CONTENTS'
result = {'actual_chain_exit': 0, 'repository_signatures': 2,
          'signed_binary_indices': indices, 'authenticated_package_count': len(wanted),
          'fresh_unpack_matches_used_observer': True, 'file_and_symlink_members': len(fresh),
          'source_or_binary_correctness_proved': False,
          'observer_profile_approved': False, 'admitted': False, 'end_to_end': False}
save('result.json', result)
print(json.dumps(result), flush=True)
